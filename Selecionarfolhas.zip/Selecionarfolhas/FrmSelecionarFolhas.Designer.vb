﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmSelecionarFolhas
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblInstrucoes = New System.Windows.Forms.Label()
        Me.btnSelecionarTodas = New System.Windows.Forms.Button()
        Me.btnDesmarcarTodas = New System.Windows.Forms.Button()
        Me.btnSelecionarPrefixo = New System.Windows.Forms.Button()
        Me.btnConfirmar = New System.Windows.Forms.Button()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.chkSelecionar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.txtNome = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.imgMiniatura = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.btnSelecionarFrameGenerator = New System.Windows.Forms.Button()
        Me.btnSelecionarSheetMetalDobras = New System.Windows.Forms.Button()
        Me.btnSelecionarMontagensExplodidas = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblInstrucoes
        '
        Me.lblInstrucoes.AutoSize = True
        Me.lblInstrucoes.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.lblInstrucoes.Location = New System.Drawing.Point(12, 9)
        Me.lblInstrucoes.Name = "lblInstrucoes"
        Me.lblInstrucoes.Size = New System.Drawing.Size(446, 25)
        Me.lblInstrucoes.TabIndex = 0
        Me.lblInstrucoes.Text = "Marque as folhas que deseja incluir na impressão:"
        '
        'btnSelecionarTodas
        '
        Me.btnSelecionarTodas.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnSelecionarTodas.Font = New System.Drawing.Font("Franklin Gothic Medium", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSelecionarTodas.ForeColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.btnSelecionarTodas.Location = New System.Drawing.Point(0, 3)
        Me.btnSelecionarTodas.Name = "btnSelecionarTodas"
        Me.btnSelecionarTodas.Size = New System.Drawing.Size(400, 40)
        Me.btnSelecionarTodas.TabIndex = 2
        Me.btnSelecionarTodas.Text = "Selecionar Todas"
        Me.btnSelecionarTodas.UseVisualStyleBackColor = False
        '
        'btnDesmarcarTodas
        '
        Me.btnDesmarcarTodas.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnDesmarcarTodas.Font = New System.Drawing.Font("Franklin Gothic Medium", 13.8!, System.Drawing.FontStyle.Bold)
        Me.btnDesmarcarTodas.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnDesmarcarTodas.Location = New System.Drawing.Point(0, 49)
        Me.btnDesmarcarTodas.Name = "btnDesmarcarTodas"
        Me.btnDesmarcarTodas.Size = New System.Drawing.Size(400, 40)
        Me.btnDesmarcarTodas.TabIndex = 3
        Me.btnDesmarcarTodas.Text = "Desmarcar Todas"
        Me.btnDesmarcarTodas.UseVisualStyleBackColor = False
        '
        'btnSelecionarPrefixo
        '
        Me.btnSelecionarPrefixo.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnSelecionarPrefixo.Font = New System.Drawing.Font("Franklin Gothic Medium", 13.8!, System.Drawing.FontStyle.Bold)
        Me.btnSelecionarPrefixo.Location = New System.Drawing.Point(406, 3)
        Me.btnSelecionarPrefixo.Name = "btnSelecionarPrefixo"
        Me.btnSelecionarPrefixo.Size = New System.Drawing.Size(300, 40)
        Me.btnSelecionarPrefixo.TabIndex = 4
        Me.btnSelecionarPrefixo.Text = "Selecionar por Prefixo"
        Me.btnSelecionarPrefixo.UseVisualStyleBackColor = False
        '
        'btnConfirmar
        '
        Me.btnConfirmar.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnConfirmar.Font = New System.Drawing.Font("Franklin Gothic Medium", 13.8!, System.Drawing.FontStyle.Bold)
        Me.btnConfirmar.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnConfirmar.Location = New System.Drawing.Point(1312, 4)
        Me.btnConfirmar.Name = "btnConfirmar"
        Me.btnConfirmar.Size = New System.Drawing.Size(600, 90)
        Me.btnConfirmar.TabIndex = 5
        Me.btnConfirmar.Text = "Confirmar"
        Me.btnConfirmar.UseVisualStyleBackColor = False
        '
        'ImageList1
        '
        Me.ImageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.ImageList1.ImageSize = New System.Drawing.Size(16, 16)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.HighlightText
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.chkSelecionar, Me.txtNome, Me.imgMiniatura})
        Me.DataGridView1.Dock = System.Windows.Forms.DockStyle.Top
        Me.DataGridView1.GridColor = System.Drawing.SystemColors.WindowText
        Me.DataGridView1.Location = New System.Drawing.Point(0, 0)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersWidth = 51
        Me.DataGridView1.RowTemplate.Height = 70
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(1924, 862)
        Me.DataGridView1.TabIndex = 7
        '
        'chkSelecionar
        '
        Me.chkSelecionar.FillWeight = 52.94118!
        Me.chkSelecionar.HeaderText = "Selecionar"
        Me.chkSelecionar.MinimumWidth = 30
        Me.chkSelecionar.Name = "chkSelecionar"
        '
        'txtNome
        '
        Me.txtNome.FillWeight = 194.1176!
        Me.txtNome.HeaderText = "Nome da Folha"
        Me.txtNome.MinimumWidth = 300
        Me.txtNome.Name = "txtNome"
        '
        'imgMiniatura
        '
        Me.imgMiniatura.FillWeight = 52.94118!
        Me.imgMiniatura.HeaderText = "Miniatura"
        Me.imgMiniatura.MinimumWidth = 6
        Me.imgMiniatura.Name = "imgMiniatura"
        '
        'ComboBox1
        '
        Me.ComboBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(401, 51)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(907, 37)
        Me.ComboBox1.TabIndex = 8
        '
        'btnSelecionarFrameGenerator
        '
        Me.btnSelecionarFrameGenerator.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnSelecionarFrameGenerator.Font = New System.Drawing.Font("Franklin Gothic Medium", 13.8!, System.Drawing.FontStyle.Bold)
        Me.btnSelecionarFrameGenerator.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSelecionarFrameGenerator.Location = New System.Drawing.Point(712, 3)
        Me.btnSelecionarFrameGenerator.Name = "btnSelecionarFrameGenerator"
        Me.btnSelecionarFrameGenerator.Size = New System.Drawing.Size(200, 40)
        Me.btnSelecionarFrameGenerator.TabIndex = 9
        Me.btnSelecionarFrameGenerator.Text = "Frame"
        Me.btnSelecionarFrameGenerator.UseVisualStyleBackColor = False
        '
        'btnSelecionarSheetMetalDobras
        '
        Me.btnSelecionarSheetMetalDobras.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnSelecionarSheetMetalDobras.Font = New System.Drawing.Font("Franklin Gothic Medium", 13.8!, System.Drawing.FontStyle.Bold)
        Me.btnSelecionarSheetMetalDobras.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSelecionarSheetMetalDobras.Location = New System.Drawing.Point(918, 3)
        Me.btnSelecionarSheetMetalDobras.Name = "btnSelecionarSheetMetalDobras"
        Me.btnSelecionarSheetMetalDobras.Size = New System.Drawing.Size(200, 40)
        Me.btnSelecionarSheetMetalDobras.TabIndex = 10
        Me.btnSelecionarSheetMetalDobras.Text = "Dobra"
        Me.btnSelecionarSheetMetalDobras.UseVisualStyleBackColor = False
        '
        'btnSelecionarMontagensExplodidas
        '
        Me.btnSelecionarMontagensExplodidas.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnSelecionarMontagensExplodidas.Font = New System.Drawing.Font("Franklin Gothic Medium", 13.8!, System.Drawing.FontStyle.Bold)
        Me.btnSelecionarMontagensExplodidas.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSelecionarMontagensExplodidas.Location = New System.Drawing.Point(1124, 3)
        Me.btnSelecionarMontagensExplodidas.Name = "btnSelecionarMontagensExplodidas"
        Me.btnSelecionarMontagensExplodidas.Size = New System.Drawing.Size(184, 40)
        Me.btnSelecionarMontagensExplodidas.TabIndex = 11
        Me.btnSelecionarMontagensExplodidas.Text = "Montagem"
        Me.btnSelecionarMontagensExplodidas.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.LightSeaGreen
        Me.Panel1.Controls.Add(Me.btnSelecionarTodas)
        Me.Panel1.Controls.Add(Me.btnSelecionarSheetMetalDobras)
        Me.Panel1.Controls.Add(Me.btnSelecionarMontagensExplodidas)
        Me.Panel1.Controls.Add(Me.btnDesmarcarTodas)
        Me.Panel1.Controls.Add(Me.btnSelecionarPrefixo)
        Me.Panel1.Controls.Add(Me.btnSelecionarFrameGenerator)
        Me.Panel1.Controls.Add(Me.btnConfirmar)
        Me.Panel1.Controls.Add(Me.ComboBox1)
        Me.Panel1.Location = New System.Drawing.Point(0, 868)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1924, 110)
        Me.Panel1.TabIndex = 12
        '
        'FrmSelecionarFolhas
        '
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(1924, 970)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.lblInstrucoes)
        Me.Name = "FrmSelecionarFolhas"
        Me.Text = "Developed by Kreimeier & Machado – Folhas de Desenho: Seleção para Impressão"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Windows.Forms.Label
    Friend WithEvents clbSheets As Windows.Forms.CheckedListBox
    Friend WithEvents btnSelectAll As Windows.Forms.Button
    Friend WithEvents btnDeselectAll As Windows.Forms.Button
    Friend WithEvents btnSelectByPrefix As Windows.Forms.Button
    Friend WithEvents btnConfirm As Windows.Forms.Button
    Friend WithEvents FlowLayoutPanel1 As Windows.Forms.FlowLayoutPanel
    Friend WithEvents lblInstrucoes As Windows.Forms.Label
    Friend WithEvents btnSelecionarTodas As Windows.Forms.Button
    Friend WithEvents btnDesmarcarTodas As Windows.Forms.Button
    Friend WithEvents btnSelecionarPrefixo As Windows.Forms.Button
    Friend WithEvents btnConfirmar As Windows.Forms.Button
    Friend WithEvents ImageList1 As Windows.Forms.ImageList
    Friend WithEvents DataGridView1 As Windows.Forms.DataGridView
    Friend WithEvents chkSelecionar As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents txtNome As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents imgMiniatura As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ComboBox1 As Windows.Forms.ComboBox
    Friend WithEvents btnSelecionarFrameGenerator As Windows.Forms.Button
    Friend WithEvents btnSelecionarSheetMetalDobras As Windows.Forms.Button
    Friend WithEvents btnSelecionarMontagensExplodidas As Windows.Forms.Button
    Friend WithEvents Panel1 As Windows.Forms.Panel
End Class
