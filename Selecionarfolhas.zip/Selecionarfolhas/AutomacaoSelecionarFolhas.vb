﻿Imports Inventor
Imports System.Runtime.InteropServices
Imports System.Windows.Forms

<ComVisible(True)>
Public Class AutomacaoSelecionarFolhas
    Private ReadOnly _app As Inventor.Application

    Public Sub New(app As Inventor.Application)
        _app = app
    End Sub

    Public Sub ExecutarSelecaoFolhas()
        Try
            Dim oDoc As DrawingDocument = TryCast(_app.ActiveDocument, DrawingDocument)
            If oDoc Is Nothing Then
                MessageBox.Show("Abra um desenho (.idw ou .dwg do Inventor) antes de executar esta ferramenta.", "Documento inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            Dim oSheets As Sheets = oDoc.Sheets
            Dim frm As New FrmSelecionarFolhas(_app) ' <- corrigido para passar _app
            frm.SetSheets(oSheets)

            If frm.ShowDialog() = DialogResult.OK Then
                Dim selecionadas = frm.ObterFolhasSelecionadas()
                For Each sheet As Sheet In oSheets
                    sheet.ExcludeFromPrinting = Not selecionadas.Contains(sheet) ' <- corrigido para comparar objetos
                Next
                MessageBox.Show("Configuração de impressão atualizada com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("Ação cancelada pelo usuário.", "Cancelado", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

        Catch ex As Exception
            MessageBox.Show("Erro ao selecionar folhas: " & ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
End Class
