﻿Imports System.Windows.Forms
Imports Inventor
Imports System.Drawing
Imports System.Runtime.InteropServices

Public Class FrmSelecionarFolhas

    Private _sheets As Sheets
    Private _invApp As Inventor.Application

    ' Construtor
    Public Sub New(invApp As Inventor.Application)
        InitializeComponent()
        _invApp = invApp
    End Sub

    ' Inicializa folhas
    Public Sub SetSheets(sheets As Sheets)
        _sheets = sheets
        CarregarFolhas()
    End Sub
    '==========================================
    ' Evento para ajustar altura de múltiplas linhas
    ' ==========================================
    Private Sub DataGridView1_RowHeightChanged(sender As Object, e As DataGridViewRowEventArgs) Handles DataGridView1.RowHeightChanged
        Dim selecionadas = DataGridView1.SelectedRows
        If selecionadas.Count > 1 Then
            Dim altura = e.Row.Height
            For Each row As DataGridViewRow In selecionadas
                If row.Index <> e.Row.Index Then
                    row.Height = altura
                End If
            Next
        End If
    End Sub

    ' ================================================================
    ' === CARREGA FOLHAS E MINIATURAS ===============================
    ' ================================================================
    Private Sub CarregarFolhas()
        DataGridView1.Columns.Clear()
        DataGridView1.Rows.Clear()
        DataGridView1.AllowUserToAddRows = False
        DataGridView1.RowTemplate.Height = 36

        Dim colSelecionar As New DataGridViewCheckBoxColumn() With {
            .Name = "chkSelecionar",
            .HeaderText = "Selecionar",
            .Width = 30
        }
        Dim colNome As New DataGridViewTextBoxColumn() With {
            .Name = "txtNome",
            .HeaderText = "Nome da Folha",
            .Width = 300,
            .ReadOnly = True
        }
        Dim colMiniatura As New DataGridViewImageColumn() With {
            .Name = "imgMiniatura",
            .HeaderText = "Miniatura",
            .Width = 80,
            .ImageLayout = DataGridViewImageCellLayout.Zoom
        }

        DataGridView1.Columns.AddRange({colSelecionar, colNome, colMiniatura})

        For Each sheet As Sheet In _sheets
            Dim bmp = GerarMiniaturaDoModeloReferenciado(sheet)
            DataGridView1.Rows.Add(Not sheet.ExcludeFromPrinting, sheet.Name, bmp)

            DataGridView1.Rows(DataGridView1.Rows.Count - 1).Tag = sheet
        Next
    End Sub

    ' ================================================================
    ' === GERA MINIATURAS DE DOCUMENTOS REFERENCIADOS ===============
    ' ================================================================
    Private Function GerarMiniaturaDoModeloReferenciado(sheet As Sheet) As Bitmap
        Try
            If sheet.DrawingViews.Count = 0 Then Return GerarMiniaturaPadrao(sheet.Name)

            Dim refDoc = sheet.DrawingViews.Item(1).ReferencedDocumentDescriptor.ReferencedDocument
            If refDoc Is Nothing Then Return GerarMiniaturaPadrao(sheet.Name)

            Dim bmp = ObterMiniaturaEficiente(refDoc)
            If bmp IsNot Nothing Then Return bmp
            Return GerarMiniaturaPadrao(refDoc.DisplayName)

        Catch
            Return GerarMiniaturaPadrao(sheet.Name)
        End Try
    End Function

    ' ================================================================
    ' === MÉTODO EFICIENTE  =======================
    ' ================================================================
    Private Function ObterMiniaturaEficiente(doc As Inventor.Document) As Bitmap
        If doc Is Nothing Then Return Nothing

        Dim oThumb As stdole.IPictureDisp = Nothing

        ' Espera até o handle estar pronto
        Dim tentativas As Integer = 0
        Do
            Try
                oThumb = doc.Thumbnail
            Catch
                System.Threading.Thread.Sleep(50)
            End Try

            tentativas += 1
            If tentativas > 50 Then Exit Do ' timeout de ~2,5s para evitar travar
        Loop While (oThumb Is Nothing OrElse oThumb.Handle < 0)

        If oThumb Is Nothing Then Return Nothing

        Try
            Dim conv As New AxHostConverter()
            Dim img As Image = conv.GetImageFromIPictureDisp(oThumb)

            ' Gera uma miniatura menor (melhor qualidade)
            Dim callback As New Image.GetThumbnailImageAbort(Function() False)
            Dim thumb As Image = img.GetThumbnailImage(180, 180, callback, IntPtr.Zero)
            Return CType(thumb, Bitmap)
        Catch
            Return Nothing
        End Try
    End Function

    ' ================================================================
    ' === MINIATURA PADRÃO (FALHA OU SEM REFERÊNCIA) =================
    ' ================================================================
    Private Function GerarMiniaturaPadrao(nome As String) As Bitmap
        Dim bmp As New Bitmap(120, 120)
        Using g As Graphics = Graphics.FromImage(bmp)
            g.Clear(System.Drawing.Color.LightGray)
            g.DrawRectangle(Pens.Gray, 0, 0, bmp.Width - 1, bmp.Height - 1)
            g.DrawString(nome, New Font("Arial", 8, FontStyle.Bold),
                         Brushes.Black, New PointF(5, 40))
        End Using
        Return bmp
    End Function

    ' ================================================================
    ' === BOTÕES =====================================================
    ' ================================================================
    Private Sub btnSelecionarTodas_Click(sender As Object, e As EventArgs) Handles btnSelecionarTodas.Click
        For Each row As DataGridViewRow In DataGridView1.Rows
            row.Cells("chkSelecionar").Value = True
        Next
    End Sub

    Private Sub btnDesmarcarTodas_Click(sender As Object, e As EventArgs) Handles btnDesmarcarTodas.Click
        For Each row As DataGridViewRow In DataGridView1.Rows
            row.Cells("chkSelecionar").Value = False
        Next
    End Sub


    Private Sub FrmSelecionarFolhas_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Lista completa de categorias
        Dim categoriasDisponiveis As New List(Of String) From {
        "27 - INTERNO - CORTE LASER CH",
        "47 - INTERNO - CORTE LASER TB",
        "30 - INTERNO - SERRA FITA",
        "33 - INTERNO - USINAGEM",
        "28 - INTERNO - DOBRA",
        "38 - INTERNO - ELÉTRICA / AUTOMAÇÃO",
        "29 - INTERNO - MONTAGEM / SOLDA",
        "32 - INTERNO - MONTAGEM FINAL",
        "42 - EXTERNO - USINAGEM – POLÍMEROS",
        "43 - EXTERNO - USINAGEM – ALUMÍNIO",
        "44 - EXTERNO - USINAGEM – POLICARBONATO",
        "45 - EXTERNO - USINAGEM – ELETROFUSÃO",
        "46 - EXTERNO - USINAGEM – INOX"
    }

        ' Adiciona os textos completos no ComboBox
        ComboBox1.Items.AddRange(categoriasDisponiveis.ToArray())
    End Sub

    Private Sub btnSelecionarPrefixo_Click(sender As Object, e As EventArgs) Handles btnSelecionarPrefixo.Click
        If String.IsNullOrWhiteSpace(ComboBox1.Text) Then
            MessageBox.Show("Selecione uma categoria antes de continuar.", "Categoria obrigatória",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Extrai apenas o prefixo numérico antes do primeiro " - "
        Dim textoCompleto As String = ComboBox1.Text.Trim()
        Dim prefixo As String = textoCompleto.Split("-"c)(0).Trim()

        Dim selecionadas As Integer = 0

        ' Marca todas as folhas cujo nome começa com o prefixo
        For Each row As DataGridViewRow In DataGridView1.Rows
            Dim nomeFolha As String = row.Cells("txtNome").Value.ToString()
            If nomeFolha.StartsWith(prefixo, StringComparison.OrdinalIgnoreCase) Then
                row.Cells("chkSelecionar").Value = True
                selecionadas += 1
            End If
        Next

        MessageBox.Show($"{selecionadas} folhas marcadas com o prefixo {prefixo}.", "Seleção concluída",
                    MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub
    Private Sub btnSelecionarFrameGenerator_Click(sender As Object, e As EventArgs) Handles btnSelecionarFrameGenerator.Click
        Try
            If DataGridView1.Rows.Count = 0 Then
                MessageBox.Show("Nenhuma folha foi carregada na lista.", "Aviso",
                            MessageBoxButtons.OK, MessageBoxIcon.Information)
                Exit Sub
            End If

            Dim selecionadas As Integer = 0

            ' Percorre todas as linhas do DataGridView
            For Each row As DataGridViewRow In DataGridView1.Rows
                ' Ignora linhas novas ou vazias
                If row.IsNewRow OrElse row.Tag Is Nothing Then Continue For

                Dim sheet As Sheet = TryCast(row.Tag, Sheet)
                If sheet Is Nothing Then Continue For

                Dim marcarLinha As Boolean = False

                ' Percorre todas as views da folha
                For Each drawingView As DrawingView In sheet.DrawingViews
                    Dim desc = drawingView.ReferencedDocumentDescriptor
                    If desc Is Nothing Then Continue For

                    Dim oModel As Document = desc.ReferencedDocument
                    If oModel Is Nothing Then Continue For

                    ' Apenas peças (Parts)
                    If oModel.DocumentType <> DocumentTypeEnum.kPartDocumentObject Then Continue For

                    ' === Verifica se é Frame Generator ===
                    Try
                        If oModel.DocumentInterests.HasInterest("{AC211AE0-A7A5-4589-916D-81C529DA6D17}") Then
                            marcarLinha = True
                            Exit For
                        End If
                    Catch
                        ' Se o documento não suportar DocumentInterests
                        Continue For
                    End Try
                Next

                ' Marca o checkbox se for uma folha com peça do Frame Generator
                If marcarLinha Then
                    If DataGridView1.Columns.Contains("chkSelecionar") Then
                        row.Cells("chkSelecionar").Value = True
                        selecionadas += 1
                    End If
                End If
            Next

            ' Exibe resultado
            MessageBox.Show($"{selecionadas} folha(s) foram selecionadas contendo peças geradas pelo Frame Generator.",
                        "Seleção Concluída", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MessageBox.Show("Erro ao selecionar folhas: " & ex.Message,
                        "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnSelecionarSheetMetalDobras_Click(sender As Object, e As EventArgs) Handles btnSelecionarSheetMetalDobras.Click
        Try
            If DataGridView1.Rows.Count = 0 Then
                MessageBox.Show("Nenhuma folha foi carregada na lista.", "Aviso",
                            MessageBoxButtons.OK, MessageBoxIcon.Information)
                Exit Sub
            End If

            Dim selecionadas As Integer = 0

            ' Percorre todas as linhas do DataGridView
            For Each row As DataGridViewRow In DataGridView1.Rows
                ' Ignora linhas novas ou vazias
                If row.IsNewRow OrElse row.Tag Is Nothing Then Continue For

                Dim sheet As Sheet = TryCast(row.Tag, Sheet)
                If sheet Is Nothing Then Continue For

                Dim marcarLinha As Boolean = False

                ' Percorre todas as views da folha
                For Each drawingView As DrawingView In sheet.DrawingViews
                    Dim desc = drawingView.ReferencedDocumentDescriptor
                    If desc Is Nothing Then Continue For

                    Dim oModel As Document = desc.ReferencedDocument
                    If oModel Is Nothing Then Continue For

                    ' Apenas peças (Parts)
                    If oModel.DocumentType <> DocumentTypeEnum.kPartDocumentObject Then Continue For

                    ' === Verifica se é uma peça de Chapa Metálica com dobras ===
                    Try
                        If oModel.DocumentSubType.DocumentSubTypeID = "{9C464203-9BAE-11D3-8BAD-0060B0CE6BB4}" Then
                            Dim sm As SheetMetalComponentDefinition =
                            TryCast(oModel.ComponentDefinition, SheetMetalComponentDefinition)

                            If sm IsNot Nothing AndAlso sm.Bends IsNot Nothing AndAlso sm.Bends.Count > 0 Then
                                marcarLinha = True
                                Exit For
                            End If
                        End If
                    Catch
                        Continue For
                    End Try
                Next

                ' Marca o checkbox se for uma folha com peça dobrada
                If marcarLinha Then
                    If DataGridView1.Columns.Contains("chkSelecionar") Then
                        row.Cells("chkSelecionar").Value = True
                        selecionadas += 1
                    End If
                End If
            Next

            ' Exibe resultado
            MessageBox.Show($"{selecionadas} folha(s) foram selecionadas contendo peças de chapa metálica com dobras.",
                        "Seleção Concluída", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MessageBox.Show("Erro ao selecionar folhas de chapa metálica: " & ex.Message,
                        "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnSelecionarMontagensExplodidas_Click(sender As Object, e As EventArgs) Handles btnSelecionarMontagensExplodidas.Click
        Try
            If DataGridView1.Rows.Count = 0 Then
                MessageBox.Show("Nenhuma folha foi carregada na lista.", "Aviso",
                            MessageBoxButtons.OK, MessageBoxIcon.Information)
                Exit Sub
            End If

            Dim selecionadas As Integer = 0

            ' Percorre todas as linhas do DataGridView
            For Each row As DataGridViewRow In DataGridView1.Rows
                If row.IsNewRow OrElse row.Tag Is Nothing Then Continue For

                Dim sheet As Sheet = TryCast(row.Tag, Sheet)
                If sheet Is Nothing Then Continue For

                Dim marcarLinha As Boolean = False

                ' Percorre todas as vistas da folha
                For Each drawingView As DrawingView In sheet.DrawingViews
                    Dim desc = drawingView.ReferencedDocumentDescriptor
                    If desc Is Nothing Then Continue For

                    Dim oModel As Document = desc.ReferencedDocument
                    If oModel Is Nothing Then Continue For

                    ' Verifica se é montagem (.iam) ou apresentação (.ipn)
                    Select Case oModel.DocumentType
                        Case DocumentTypeEnum.kAssemblyDocumentObject
                            marcarLinha = True
                            Exit For

                        Case DocumentTypeEnum.kPresentationDocumentObject
                            marcarLinha = True
                            Exit For
                    End Select
                Next

                ' Marca o checkbox se a folha contém montagem ou vista explodida
                If marcarLinha Then
                    If DataGridView1.Columns.Contains("chkSelecionar") Then
                        row.Cells("chkSelecionar").Value = True
                        selecionadas += 1
                    End If
                End If
            Next

            ' Garante que a primeira folha esteja sempre ativa
            If DataGridView1.Rows.Count > 0 Then
                Dim primeira As DataGridViewRow = DataGridView1.Rows(0)
                primeira.Cells("chkSelecionar").Value = True
            End If

            ' Exibe resultado
            MessageBox.Show($"{selecionadas} folha(s) foram selecionadas contendo montagens ou vistas explodidas.",
                        "Seleção Concluída", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MessageBox.Show("Erro ao selecionar folhas de montagem/explodidas: " & ex.Message,
                        "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub




    Private Sub btnConfirmar_Click(sender As Object, e As EventArgs) Handles btnConfirmar.Click
        Try
            For Each row As DataGridViewRow In DataGridView1.Rows
                Dim sheet As Sheet = CType(row.Tag, Sheet)
                Dim selecionada As Boolean = CBool(row.Cells("chkSelecionar").Value)
                sheet.ExcludeFromPrinting = Not selecionada
            Next

            MessageBox.Show("Configuração de impressão atualizada com sucesso!",
                            "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Me.DialogResult = DialogResult.OK
            Me.Close()
        Catch ex As Exception
            MessageBox.Show("Erro ao atualizar folhas: " & ex.Message, "Erro",
                            MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' ================================================================
    ' === OBTÉM LISTA DE FOLHAS SELECIONADAS =========================
    ' ================================================================
    Public Function ObterFolhasSelecionadas() As List(Of Sheet)
        Dim selecionadas As New List(Of Sheet)
        For Each row As DataGridViewRow In DataGridView1.Rows
            If CBool(row.Cells("chkSelecionar").Value) Then
                selecionadas.Add(CType(row.Tag, Sheet))
            End If
        Next
        Return selecionadas
    End Function

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub
End Class

' ================================================================
' === CONVERSOR AxHost (igual ao do iLogic) =======================
' ================================================================
Public Class AxHostConverter
    Inherits System.Windows.Forms.AxHost
    Public Sub New()
        MyBase.New((New Guid).ToString)
    End Sub
    Public Function GetImageFromIPictureDisp(ByVal IPDisp As stdole.IPictureDisp) As Image
        Return MyBase.GetPictureFromIPicture(IPDisp)
    End Function
End Class

