﻿Imports System.Drawing
Imports System.IO
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Windows.Forms
Imports Inventor
Imports stdoleIPictureDisp = stdole.IPictureDisp

<ComVisible(True)>
<Guid("7f3a0e85-7578-4454-9349-edd30a8a134c")>
Public Class StandardAddInServerSubstituirModelodeReferencia
    Implements ApplicationAddInServer

    Private _inventorApp As Inventor.Application
    Private _automacaoSubstituirReferencia As AutomacaoSubstituirModelodeReferencia
    Private botaoSubstituir As ButtonDefinition

    Public ReadOnly Property Automation As Object Implements ApplicationAddInServer.Automation
        Get
            Return _automacaoSubstituirReferencia
        End Get
    End Property

    Public Sub Activate(addInSiteObject As ApplicationAddInSite, firstTime As Boolean) Implements ApplicationAddInServer.Activate
        _inventorApp = addInSiteObject.Application
        _automacaoSubstituirReferencia = New AutomacaoSubstituirModelodeReferencia(_inventorApp)

        Try
            Dim controlDefs As ControlDefinitions = _inventorApp.CommandManager.ControlDefinitions
            Dim assembly As Assembly = Assembly.GetExecutingAssembly()

            ' === Carregar ícones embutidos (opcional) ===
            Dim smallIcon As stdoleIPictureDisp = Nothing
            Dim largeIcon As stdoleIPictureDisp = Nothing

            Try
                Dim resources = assembly.GetManifestResourceNames()
                Dim resource16 = resources.FirstOrDefault(Function(r) r.EndsWith("16x16.ico"))
                Dim resource32 = resources.FirstOrDefault(Function(r) r.EndsWith("32x32.ico"))

                If resource16 IsNot Nothing Then
                    Using stream16 As Stream = assembly.GetManifestResourceStream(resource16)
                        smallIcon = IconToIPictureDisp(New Icon(stream16))
                    End Using
                End If
                If resource32 IsNot Nothing Then
                    Using stream32 As Stream = assembly.GetManifestResourceStream(resource32)
                        largeIcon = IconToIPictureDisp(New Icon(stream32))
                    End Using
                End If
            Catch
                ' ícones opcionais
            End Try

            ' === Criar ou obter botão do Add-In ===
            Try
                botaoSubstituir = DirectCast(controlDefs.Item("MyCompany_Substituir"), ButtonDefinition)
            Catch
                botaoSubstituir = controlDefs.AddButtonDefinition(
                    "Substituir" & vbCrLf & "Referência",
                    "MyCompany_Substituir",
                    CommandTypesEnum.kEditMaskCmdType,
                    Me.GetType().GUID.ToString("B"),
                    "Substituir Modelo de Referência",
                    "Substituir" & vbCrLf & "Referência",
                    smallIcon,
                    largeIcon)
            End Try

            AddHandler botaoSubstituir.OnExecute, AddressOf botaoSubstituir_OnExecute

            ' === Adicionar botão à aba Drawing / Tab Tools ===
            Dim ribbonDraw As Ribbon = _inventorApp.UserInterfaceManager.Ribbons("Drawing")
            Dim tabTools As RibbonTab = ribbonDraw.RibbonTabs("id_TabTools")
            Dim painel As RibbonPanel = Nothing
            Try
                painel = tabTools.RibbonPanels.Item("PainelSubstituirReferência")
            Catch
                painel = tabTools.RibbonPanels.Add("Substituir" & vbCrLf & "Referência", "PainelSubstituirReferência", Me.GetType().GUID.ToString("B"))
            End Try

            Dim existe As Boolean = painel.CommandControls.OfType(Of CommandControl)().Any(Function(c) c.ControlDefinition.InternalName = "MyCompany_Substituir")
            If Not existe Then
                painel.CommandControls.AddButton(botaoSubstituir, True)
            End If

        Catch ex As Exception
            MessageBox.Show("Erro ao ativar Add-In: " & ex.Message)
        End Try
    End Sub

    Private Sub botaoSubstituir_OnExecute(Context As NameValueMap)
        Try
            _automacaoSubstituirReferencia.ExecutarSelecaoFolhas()
        Catch ex As Exception
            MessageBox.Show("Erro ao executar ferramenta: " & ex.Message)
        End Try
    End Sub

    Public Sub Deactivate() Implements ApplicationAddInServer.Deactivate
        _inventorApp = Nothing
        _automacaoSubstituirReferencia = Nothing
    End Sub

    Public Sub ExecuteCommand(commandID As Integer) Implements ApplicationAddInServer.ExecuteCommand
        ' não utilizado
    End Sub

    ' Converte Icon para IPictureDisp
    Private Function IconToIPictureDisp(icon As Icon) As stdoleIPictureDisp
        Return AxHostConverter.ImageToPictureDisp(icon.ToBitmap())
    End Function

    Private Class AxHostConverter
        Inherits AxHost
        Private Sub New()
            MyBase.New(String.Empty)
        End Sub
        Public Shared Function ImageToPictureDisp(image As Drawing.Image) As stdoleIPictureDisp
            Return CType(GetIPictureDispFromPicture(image), stdoleIPictureDisp)
        End Function
    End Class
End Class
