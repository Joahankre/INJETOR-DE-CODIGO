﻿Imports Inventor
Imports System.Runtime.InteropServices
Imports System.Windows.Forms

<ComVisible(True)>
Public Class AutomacaoSubstituirModelodeReferencia

    Private ReadOnly _app As Inventor.Application

    Public Sub New(app As Inventor.Application)
        _app = app
    End Sub

    Public Sub ExecutarSelecaoFolhas()

        Try
            ' Verifica se o documento ativo é um desenho
            Dim oDoc As DrawingDocument = TryCast(_app.ActiveDocument, DrawingDocument)
            If oDoc Is Nothing Then
                MessageBox.Show("Abra um desenho (.idw ou .dwg) antes de executar.",
                                "Documento inválido",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning)
                Return
            End If

            ' Abre o formulário
            Dim frm As New FrmSubstituirReferencia(_app)
            frm.SetSheets(oDoc.Sheets)

            frm.ShowDialog()

        Catch ex As Exception
            MessageBox.Show("Erro geral: " & ex.Message,
                            "Erro",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
        End Try

    End Sub

End Class

