﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmSubstituirReferencia
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblInstrucoes = New System.Windows.Forms.Label()
        Me.btnSelecionarMesmoArquivo = New System.Windows.Forms.Button()
        Me.btnDesmarcarTodas = New System.Windows.Forms.Button()
        Me.btnConfirmar = New System.Windows.Forms.Button()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.chkSelecionar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.txtNome = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.imgMiniatura = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnSubstituirModelo = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblInstrucoes
        '
        Me.lblInstrucoes.AutoSize = True
        Me.lblInstrucoes.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.lblInstrucoes.Location = New System.Drawing.Point(12, 9)
        Me.lblInstrucoes.Name = "lblInstrucoes"
        Me.lblInstrucoes.Size = New System.Drawing.Size(360, 20)
        Me.lblInstrucoes.TabIndex = 0
        Me.lblInstrucoes.Text = "Marque as folhas que deseja incluir na impressão:"
        '
        'btnSelecionarMesmoArquivo
        '
        Me.btnSelecionarMesmoArquivo.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnSelecionarMesmoArquivo.Font = New System.Drawing.Font("Franklin Gothic Medium", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSelecionarMesmoArquivo.ForeColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.btnSelecionarMesmoArquivo.Location = New System.Drawing.Point(3, 3)
        Me.btnSelecionarMesmoArquivo.Name = "btnSelecionarMesmoArquivo"
        Me.btnSelecionarMesmoArquivo.Size = New System.Drawing.Size(470, 40)
        Me.btnSelecionarMesmoArquivo.TabIndex = 2
        Me.btnSelecionarMesmoArquivo.Text = "Selecionar Mesmo Arquivo"
        Me.btnSelecionarMesmoArquivo.UseVisualStyleBackColor = False
        '
        'btnDesmarcarTodas
        '
        Me.btnDesmarcarTodas.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnDesmarcarTodas.Font = New System.Drawing.Font("Franklin Gothic Medium", 13.8!, System.Drawing.FontStyle.Bold)
        Me.btnDesmarcarTodas.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnDesmarcarTodas.Location = New System.Drawing.Point(482, 3)
        Me.btnDesmarcarTodas.Name = "btnDesmarcarTodas"
        Me.btnDesmarcarTodas.Size = New System.Drawing.Size(470, 40)
        Me.btnDesmarcarTodas.TabIndex = 3
        Me.btnDesmarcarTodas.Text = "Desmarcar Todas"
        Me.btnDesmarcarTodas.UseVisualStyleBackColor = False
        '
        'btnConfirmar
        '
        Me.btnConfirmar.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnConfirmar.Font = New System.Drawing.Font("Franklin Gothic Medium", 13.8!, System.Drawing.FontStyle.Bold)
        Me.btnConfirmar.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnConfirmar.Location = New System.Drawing.Point(1434, 3)
        Me.btnConfirmar.Name = "btnConfirmar"
        Me.btnConfirmar.Size = New System.Drawing.Size(485, 40)
        Me.btnConfirmar.TabIndex = 5
        Me.btnConfirmar.Text = "Confirmar"
        Me.btnConfirmar.UseVisualStyleBackColor = False
        '
        'ImageList1
        '
        Me.ImageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.ImageList1.ImageSize = New System.Drawing.Size(16, 16)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.HighlightText
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.chkSelecionar, Me.txtNome, Me.imgMiniatura})
        Me.DataGridView1.Dock = System.Windows.Forms.DockStyle.Top
        Me.DataGridView1.GridColor = System.Drawing.SystemColors.WindowText
        Me.DataGridView1.Location = New System.Drawing.Point(0, 0)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersWidth = 51
        Me.DataGridView1.RowTemplate.Height = 70
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(1924, 1003)
        Me.DataGridView1.TabIndex = 7
        '
        'chkSelecionar
        '
        Me.chkSelecionar.FillWeight = 52.94118!
        Me.chkSelecionar.HeaderText = "Selecionar"
        Me.chkSelecionar.MinimumWidth = 30
        Me.chkSelecionar.Name = "chkSelecionar"
        '
        'txtNome
        '
        Me.txtNome.FillWeight = 194.1176!
        Me.txtNome.HeaderText = "Nome da Folha"
        Me.txtNome.MinimumWidth = 300
        Me.txtNome.Name = "txtNome"
        '
        'imgMiniatura
        '
        Me.imgMiniatura.FillWeight = 52.94118!
        Me.imgMiniatura.HeaderText = "Miniatura"
        Me.imgMiniatura.MinimumWidth = 6
        Me.imgMiniatura.Name = "imgMiniatura"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.LightCoral
        Me.Panel1.Controls.Add(Me.btnSubstituirModelo)
        Me.Panel1.Controls.Add(Me.btnSelecionarMesmoArquivo)
        Me.Panel1.Controls.Add(Me.btnDesmarcarTodas)
        Me.Panel1.Controls.Add(Me.btnConfirmar)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 1009)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1924, 52)
        Me.Panel1.TabIndex = 12
        '
        'btnSubstituirModelo
        '
        Me.btnSubstituirModelo.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnSubstituirModelo.Font = New System.Drawing.Font("Franklin Gothic Medium", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSubstituirModelo.ForeColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.btnSubstituirModelo.Location = New System.Drawing.Point(958, 3)
        Me.btnSubstituirModelo.Name = "btnSubstituirModelo"
        Me.btnSubstituirModelo.Size = New System.Drawing.Size(470, 40)
        Me.btnSubstituirModelo.TabIndex = 6
        Me.btnSubstituirModelo.Text = "Aplicar Substituição"
        Me.btnSubstituirModelo.UseVisualStyleBackColor = False
        '
        'FrmSubstituirReferencia
        '
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(1924, 1061)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.lblInstrucoes)
        Me.Name = "FrmSubstituirReferencia"
        Me.Text = "Developed by Kreimeier & Machado – Substituição do Modelo de Referência"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Windows.Forms.Label
    Friend WithEvents clbSheets As Windows.Forms.CheckedListBox
    Friend WithEvents btnSelectAll As Windows.Forms.Button
    Friend WithEvents btnDeselectAll As Windows.Forms.Button
    Friend WithEvents btnSelectByPrefix As Windows.Forms.Button
    Friend WithEvents btnConfirm As Windows.Forms.Button
    Friend WithEvents FlowLayoutPanel1 As Windows.Forms.FlowLayoutPanel
    Friend WithEvents lblInstrucoes As Windows.Forms.Label
    Friend WithEvents btnSelecionarMesmoArquivo As Windows.Forms.Button
    Friend WithEvents btnDesmarcarTodas As Windows.Forms.Button
    Friend WithEvents btnConfirmar As Windows.Forms.Button
    Friend WithEvents ImageList1 As Windows.Forms.ImageList
    Friend WithEvents DataGridView1 As Windows.Forms.DataGridView
    Friend WithEvents chkSelecionar As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents txtNome As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents imgMiniatura As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Panel1 As Windows.Forms.Panel
    Friend WithEvents btnSubstituirModelo As Windows.Forms.Button
End Class
