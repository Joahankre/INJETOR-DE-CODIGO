﻿Imports System.Windows.Forms
Imports Inventor
Imports System.Drawing
Imports System.Runtime.InteropServices

Public Class FrmSubstituirReferencia

    Private _sheets As Sheets
    Private _invApp As Inventor.Application

    ' Construtor
    Public Sub New(invApp As Inventor.Application)
        InitializeComponent()
        _invApp = invApp
    End Sub

    ' Inicializa folhas
    Public Sub SetSheets(sheets As Sheets)
        _sheets = sheets
        CarregarFolhas()
    End Sub
    '==========================================
    ' Evento para ajustar altura de múltiplas linhas
    ' ==========================================
    Private Sub DataGridView1_RowHeightChanged(sender As Object, e As DataGridViewRowEventArgs) Handles DataGridView1.RowHeightChanged
        Dim selecionadas = DataGridView1.SelectedRows
        If selecionadas.Count > 1 Then
            Dim altura = e.Row.Height
            For Each row As DataGridViewRow In selecionadas
                If row.Index <> e.Row.Index Then
                    row.Height = altura
                End If
            Next
        End If
    End Sub
    ' ================================================================
    ' === CARREGA FOLHAS E MINIATURAS + CAMINHO DO ARQUIVO ===========
    ' ================================================================
    Private Sub CarregarFolhas()
        DataGridView1.Columns.Clear()
        DataGridView1.Rows.Clear()
        DataGridView1.AllowUserToAddRows = False
        DataGridView1.RowTemplate.Height = 36

        Dim colSelecionar As New DataGridViewCheckBoxColumn() With {
        .Name = "chkSelecionar",
        .HeaderText = "Selecionar",
        .Width = 30
    }
        Dim colNome As New DataGridViewTextBoxColumn() With {
        .Name = "txtNome",
        .HeaderText = "Nome da Folha",
        .Width = 300,
        .ReadOnly = True
    }
        Dim colMiniatura As New DataGridViewImageColumn() With {
        .Name = "imgMiniatura",
        .HeaderText = "Miniatura",
        .Width = 80,
        .ImageLayout = DataGridViewImageCellLayout.Zoom
    }

        Dim colCaminho As New DataGridViewTextBoxColumn() With {
        .Name = "txtCaminho",
        .HeaderText = "Caminho do Arquivo",
        .Width = 350,
        .ReadOnly = True
    }

        DataGridView1.Columns.AddRange({colSelecionar, colNome, colMiniatura, colCaminho})

        For Each sheet As Sheet In _sheets

            Dim bmp = GerarMiniaturaDoModeloReferenciado(sheet)

            ' ===== CAMINHO DO ARQUIVO REFERENCIADO =====
            Dim caminhoArquivo As String = ""
            Try
                If sheet.DrawingViews.Count > 0 Then
                    Dim refDoc = sheet.DrawingViews.Item(1).ReferencedDocumentDescriptor.ReferencedDocument
                    If refDoc IsNot Nothing Then
                        caminhoArquivo = refDoc.FullDocumentName
                    End If
                End If
            Catch
            End Try

            DataGridView1.Rows.Add(Not sheet.ExcludeFromPrinting,
                               sheet.Name,
                               bmp,
                               caminhoArquivo)

            DataGridView1.Rows(DataGridView1.Rows.Count - 1).Tag = sheet
        Next
    End Sub


    ' ================================================================
    ' === GERA MINIATURAS DE DOCUMENTOS REFERENCIADOS ===============
    ' ================================================================
    Private Function GerarMiniaturaDoModeloReferenciado(sheet As Sheet) As Bitmap
        Try
            If sheet.DrawingViews.Count = 0 Then Return GerarMiniaturaPadrao(sheet.Name)

            Dim refDoc = sheet.DrawingViews.Item(1).ReferencedDocumentDescriptor.ReferencedDocument
            If refDoc Is Nothing Then Return GerarMiniaturaPadrao(sheet.Name)

            Dim bmp = ObterMiniaturaEficiente(refDoc)
            If bmp IsNot Nothing Then Return bmp
            Return GerarMiniaturaPadrao(refDoc.DisplayName)

        Catch
            Return GerarMiniaturaPadrao(sheet.Name)
        End Try
    End Function

    ' ================================================================
    ' === MÉTODO EFICIENTE  =======================
    ' ================================================================
    Private Function ObterMiniaturaEficiente(doc As Inventor.Document) As Bitmap
        If doc Is Nothing Then Return Nothing

        Dim oThumb As stdole.IPictureDisp = Nothing

        ' Espera até o handle estar pronto
        Dim tentativas As Integer = 0
        Do
            Try
                oThumb = doc.Thumbnail
            Catch
                System.Threading.Thread.Sleep(50)
            End Try

            tentativas += 1
            If tentativas > 50 Then Exit Do ' timeout de ~2,5s para evitar travar
        Loop While (oThumb Is Nothing OrElse oThumb.Handle < 0)

        If oThumb Is Nothing Then Return Nothing

        Try
            Dim conv As New AxHostConverter()
            Dim img As Image = conv.GetImageFromIPictureDisp(oThumb)

            ' Gera uma miniatura menor (melhor qualidade)
            Dim callback As New Image.GetThumbnailImageAbort(Function() False)
            Dim thumb As Image = img.GetThumbnailImage(180, 180, callback, IntPtr.Zero)
            Return CType(thumb, Bitmap)
        Catch
            Return Nothing
        End Try
    End Function

    ' ================================================================
    ' === MINIATURA PADRÃO (FALHA OU SEM REFERÊNCIA) =================
    ' ================================================================
    Private Function GerarMiniaturaPadrao(nome As String) As Bitmap
        Dim bmp As New Bitmap(120, 120)
        Using g As Graphics = Graphics.FromImage(bmp)
            g.Clear(System.Drawing.Color.LightGray)
            g.DrawRectangle(Pens.Gray, 0, 0, bmp.Width - 1, bmp.Height - 1)
            g.DrawString(nome, New Font("Arial", 8, FontStyle.Bold),
                         Brushes.Black, New PointF(5, 40))
        End Using
        Return bmp
    End Function

    ' ================================================================
    ' === BOTÕES =====================================================
    ' ================================================================
    Private Sub btnSelecionarMesmoArquivo_Click(sender As Object, e As EventArgs) Handles btnSelecionarMesmoArquivo.Click
        ' Verifica se alguma linha está selecionada
        If DataGridView1.SelectedRows.Count = 0 Then
            MessageBox.Show("Selecione uma folha para encontrar referências iguais.", "Aviso",
                        MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If

        ' Obtém a primeira folha selecionada
        Dim linhaSelecionada As DataGridViewRow = DataGridView1.SelectedRows(0)
        Dim caminhoReferencia As String = CStr(linhaSelecionada.Cells("txtCaminho").Value)

        If String.IsNullOrEmpty(caminhoReferencia) Then
            MessageBox.Show("A folha selecionada não possui referência de arquivo.", "Aviso",
                        MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If

        ' Percorre todas as folhas e seleciona as que têm o mesmo caminho de referência
        For Each row As DataGridViewRow In DataGridView1.Rows
            Dim caminho As String = CStr(row.Cells("txtCaminho").Value)
            row.Cells("chkSelecionar").Value = (caminho.Equals(caminhoReferencia, StringComparison.OrdinalIgnoreCase))
        Next
    End Sub


    Private Sub btnDesmarcarTodas_Click(sender As Object, e As EventArgs) Handles btnDesmarcarTodas.Click
        For Each row As DataGridViewRow In DataGridView1.Rows
            row.Cells("chkSelecionar").Value = False
        Next
    End Sub

    Private Sub btnConfirmar_Click(sender As Object, e As EventArgs) Handles btnConfirmar.Click
        Try
            For Each row As DataGridViewRow In DataGridView1.Rows
                Dim sheet As Sheet = CType(row.Tag, Sheet)
                Dim selecionada As Boolean = CBool(row.Cells("chkSelecionar").Value)
                sheet.ExcludeFromPrinting = Not selecionada
            Next

            MessageBox.Show("Configuração de impressão atualizada com sucesso!",
                            "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Me.DialogResult = DialogResult.OK
            Me.Close()
        Catch ex As Exception
            MessageBox.Show("Erro ao atualizar folhas: " & ex.Message, "Erro",
                            MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub btnSubstituirModelo_Click(sender As Object, e As EventArgs) Handles btnSubstituirModelo.Click
        Try
            Using dlg As New OpenFileDialog()
                dlg.Filter = "Arquivos Inventor|*.ipt;*.iam"
                dlg.Title = "Selecione o novo modelo de referência"

                If dlg.ShowDialog() <> DialogResult.OK Then Return

                Dim novoCaminho As String = dlg.FileName

                For Each row As DataGridViewRow In DataGridView1.Rows
                    If Not CBool(row.Cells("chkSelecionar").Value) Then Continue For

                    Dim sheet As Sheet = CType(row.Tag, Sheet)

                    ' Ativa a folha antes da substituição
                    Try
                        sheet.Activate()
                    Catch
                    End Try

                    For Each view As DrawingView In sheet.DrawingViews
                        Try
                            Dim desc = view.ReferencedDocumentDescriptor
                            Dim fileDesc = desc.ReferencedFileDescriptor

                            ' 1) Tenta método principal da API
                            Try
                                fileDesc.ReplaceReference(novoCaminho)
                                desc.Update()
                                Continue For
                            Catch ex1 As Exception
                                ' falhou → tenta comando nativo
                            End Try

                            ' 2) Fallback: comando nativo do Inventor
                            Try
                                Dim cmd = _invApp.CommandManager.ControlDefinitions.Item("DrawingReplaceModelReferenceCmd")
                                cmd.Execute2(True)
                            Catch exCmd As Exception
                                MessageBox.Show(
                                $"Falha ao substituir modelo na folha '{sheet.Name}' na view '{view.Name}':{vbCrLf}{exCmd.Message}",
                                "Erro",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error)
                            End Try

                        Catch ex As Exception
                            MessageBox.Show(
                            $"Erro na folha '{sheet.Name}' ao substituir modelo:{vbCrLf}{ex.Message}",
                            "Erro na View",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
                        End Try
                    Next

                    row.Cells("imgMiniatura").Value = GerarMiniaturaDoModeloReferenciado(sheet)
                    row.Cells("txtCaminho").Value = novoCaminho
                Next

                MessageBox.Show("Modelo de referência substituído com sucesso!", "Sucesso",
                            MessageBoxButtons.OK, MessageBoxIcon.Information)

            End Using

        Catch ex As Exception
            MessageBox.Show("Erro ao substituir referência: " & ex.Message,
                        "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub



    ' ================================================================
    ' === OBTÉM LISTA DE FOLHAS SELECIONADAS =========================
    ' ================================================================
    Public Function ObterFolhasSelecionadas() As List(Of Sheet)
        Dim selecionadas As New List(Of Sheet)
        For Each row As DataGridViewRow In DataGridView1.Rows
            If CBool(row.Cells("chkSelecionar").Value) Then
                selecionadas.Add(CType(row.Tag, Sheet))
            End If
        Next
        Return selecionadas
    End Function

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub FrmSelecionarFolhas_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class

' ================================================================
' === CONVERSOR AxHost (igual ao do iLogic) =======================
' ================================================================
Public Class AxHostConverter
    Inherits System.Windows.Forms.AxHost
    Public Sub New()
        MyBase.New((New Guid).ToString)
    End Sub
    Public Function GetImageFromIPictureDisp(ByVal IPDisp As stdole.IPictureDisp) As Image
        Return MyBase.GetPictureFromIPicture(IPDisp)
    End Function
End Class

