﻿Imports System.Drawing
Imports System.Runtime.InteropServices
Imports System.Windows.Forms
Imports Autodesk.iLogic.Interfaces
Imports Autodesk.iLogic.Runtime
Imports Inventor

Imports System.Text.Json
Imports Newtonsoft.Json

Public Class FrmSelecionarFolhas

    Private _sheets As Sheets
    Private _invApp As Inventor.Application

    ' Construtor
    Public Sub New(invApp As Inventor.Application)
        InitializeComponent()
        _invApp = invApp
    End Sub

    ' Inicializa folhas
    Public Sub SetSheets(sheets As Sheets)
        _sheets = sheets
        CarregarFolhas()
    End Sub


    ' ================================================================
    ' === CARREGA FOLHAS E MINIATURAS ===============================
    ' ================================================================
    Private Sub CarregarFolhas()
        DataGridView1.Columns.Clear()
        DataGridView1.Rows.Clear()
        DataGridView1.AllowUserToAddRows = False
        DataGridView1.RowTemplate.Height = 36

        Dim colSelecionar As New DataGridViewCheckBoxColumn() With {
            .Name = "chkSelecionar",
            .HeaderText = "Selecionar",
            .Width = 30
        }
        Dim colNome As New DataGridViewTextBoxColumn() With {
            .Name = "txtNome",
            .HeaderText = "Nome da Folha",
            .Width = 300,
            .ReadOnly = True
        }
        Dim colMiniatura As New DataGridViewImageColumn() With {
            .Name = "imgMiniatura",
            .HeaderText = "Miniatura",
            .Width = 80,
            .ImageLayout = DataGridViewImageCellLayout.Zoom
        }

        DataGridView1.Columns.AddRange({colSelecionar, colNome, colMiniatura})

        For Each sheet As Sheet In _sheets
            Dim bmp = GerarMiniaturaDoModeloReferenciado(sheet)
            DataGridView1.Rows.Add(Not sheet.ExcludeFromPrinting, sheet.Name, bmp)

            DataGridView1.Rows(DataGridView1.Rows.Count - 1).Tag = sheet
        Next
    End Sub

    ' ================================================================
    ' === GERA MINIATURAS DE DOCUMENTOS REFERENCIADOS ===============
    ' ================================================================
    Private Function GerarMiniaturaDoModeloReferenciado(sheet As Sheet) As Bitmap
        Try
            If sheet.DrawingViews.Count = 0 Then Return GerarMiniaturaPadrao(sheet.Name)

            Dim refDoc = sheet.DrawingViews.Item(1).ReferencedDocumentDescriptor.ReferencedDocument
            If refDoc Is Nothing Then Return GerarMiniaturaPadrao(sheet.Name)

            Dim bmp = ObterMiniaturaEficiente(refDoc)
            If bmp IsNot Nothing Then Return bmp
            Return GerarMiniaturaPadrao(refDoc.DisplayName)

        Catch
            Return GerarMiniaturaPadrao(sheet.Name)
        End Try
    End Function

    ' ================================================================
    ' === MÉTODO EFICIENTE  =======================
    ' ================================================================
    Private Function ObterMiniaturaEficiente(doc As Inventor.Document) As Bitmap
        If doc Is Nothing Then Return Nothing

        Dim oThumb As stdole.IPictureDisp = Nothing

        ' Espera até o handle estar pronto
        Dim tentativas As Integer = 0
        Do
            Try
                oThumb = doc.Thumbnail
            Catch
                System.Threading.Thread.Sleep(50)
            End Try

            tentativas += 1
            If tentativas > 50 Then Exit Do ' timeout de ~2,5s para evitar travar
        Loop While (oThumb Is Nothing OrElse oThumb.Handle < 0)

        If oThumb Is Nothing Then Return Nothing

        Try
            Dim conv As New AxHostConverter()
            Dim img As Image = conv.GetImageFromIPictureDisp(oThumb)

            ' Gera uma miniatura menor (melhor qualidade)
            Dim callback As New Image.GetThumbnailImageAbort(Function() False)
            Dim thumb As Image = img.GetThumbnailImage(180, 180, callback, IntPtr.Zero)
            Return CType(thumb, Bitmap)
        Catch
            Return Nothing
        End Try
    End Function

    ' ================================================================
    ' === MINIATURA PADRÃO (FALHA OU SEM REFERÊNCIA) =================
    ' ================================================================
    Private Function GerarMiniaturaPadrao(nome As String) As Bitmap
        Dim bmp As New Bitmap(120, 120)
        Using g As Graphics = Graphics.FromImage(bmp)
            g.Clear(System.Drawing.Color.LightGray)
            g.DrawRectangle(Pens.Gray, 0, 0, bmp.Width - 1, bmp.Height - 1)
            g.DrawString(nome, New Font("Arial", 8, FontStyle.Bold),
                         Brushes.Black, New PointF(5, 40))
        End Using
        Return bmp
    End Function
    ' Dispara quando o usuário marca/desmarca o checkbox
    Private Sub DataGridView1_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellValueChanged
        If e.RowIndex < 0 Or e.ColumnIndex < 0 Then Return

        If DataGridView1.Columns(e.ColumnIndex).Name = "chkSelecionar" Then
            Dim row As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
            Dim selecionada As Boolean = CBool(row.Cells("chkSelecionar").Value)

            If selecionada Then
                row.Cells("txtNome").Style.ForeColor = System.Drawing.Color.Magenta
                row.Cells("txtNome").Style.Font = New Font(DataGridView1.Font, FontStyle.Bold)
            Else
                row.Cells("txtNome").Style.ForeColor = System.Drawing.Color.Black
                row.Cells("txtNome").Style.Font = DataGridView1.Font
            End If
        End If
    End Sub

    ' Commit imediato do checkbox
    Private Sub DataGridView1_CurrentCellDirtyStateChanged(sender As Object, e As EventArgs) Handles DataGridView1.CurrentCellDirtyStateChanged
        If DataGridView1.IsCurrentCellDirty Then
            DataGridView1.CommitEdit(DataGridViewDataErrorContexts.Commit)
        End If
    End Sub

    ' ================================================================
    ' === BOTÕES =====================================================
    ' ================================================================
    Private Sub btnSelecionarTodas_Click(sender As Object, e As EventArgs) Handles btnSelecionarTodas.Click
        For Each row As DataGridViewRow In DataGridView1.Rows
            row.Cells("chkSelecionar").Value = True
        Next
    End Sub

    Private Sub btnDesmarcarTodas_Click(sender As Object, e As EventArgs) Handles btnDesmarcarTodas.Click
        For Each row As DataGridViewRow In DataGridView1.Rows
            row.Cells("chkSelecionar").Value = False
        Next
    End Sub


    Private Sub FrmSelecionarFolhas_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ' Lista completa de categorias
        Dim categoriasDisponiveis As New List(Of String) From {
        "27 - INTERNO - CORTE LASER CH",
        "47 - INTERNO - CORTE LASER TB",
        "30 - INTERNO - SERRA FITA",
        "33 - INTERNO - USINAGEM",
        "28 - INTERNO - DOBRA",
        "38 - INTERNO - ELÉTRICA / AUTOMAÇÃO",
        "29 - INTERNO - MONTAGEM / SOLDA",
        "32 - INTERNO - MONTAGEM FINAL",
        "42 - EXTERNO - USINAGEM – POLÍMEROS",
        "43 - EXTERNO - USINAGEM – ALUMÍNIO",
        "44 - EXTERNO - USINAGEM – POLICARBONATO",
        "45 - EXTERNO - USINAGEM – ELETROFUSÃO",
        "46 - EXTERNO - USINAGEM – INOX"
    }

        ' Adiciona os textos completos no ComboBox
        ComboBox1.Items.AddRange(categoriasDisponiveis.ToArray())

    End Sub

    Private Sub btnSelecionarPrefixo_Folha_Click(sender As Object, e As EventArgs) Handles btnSelecionarPrefixo_Folha.Click

        If String.IsNullOrWhiteSpace(ComboBox1.Text) Then
            MessageBox.Show("Selecione uma categoria antes de continuar.", "Categoria obrigatória",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Texto completo do ComboBox
        Dim textoCompleto As String = ComboBox1.Text.Trim()

        ' Divide categorias múltiplas separadas por ;
        Dim partes = textoCompleto.Split(";"c)

        ' Lista de prefixos numéricos
        Dim prefixos As New List(Of String)

        For Each parte In partes
            Dim p = parte.Trim()
            If p.Contains("-") Then
                prefixos.Add(p.Split("-"c)(0).Trim())
            End If

        Next

        Dim selecionadas As Integer = 0

        ' Marca folhas cujo nome começa com qualquer prefixo
        For Each row As DataGridViewRow In DataGridView1.Rows
            Dim nomeFolha As String = row.Cells("txtNome").Value.ToString()

            For Each prefixo In prefixos
                If nomeFolha.StartsWith(prefixo, StringComparison.OrdinalIgnoreCase) Then
                    row.Cells("chkSelecionar").Value = True
                    selecionadas += 1
                    Exit For
                End If
            Next
        Next

        MessageBox.Show($"{selecionadas} folhas marcadas para a(s) categoria(s): {String.Join(", ", prefixos)}.",
                    "Seleção concluída", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub
    Private Sub btnSelecionarPorPrefixoInterno_Click(sender As Object, e As EventArgs) _
Handles btnSelecionarPorPrefixoInterno.Click

        Dim retornoFile As String = ""
        Dim tempRule As String = ""

        ' 1️⃣ Valida ComboBox
        If String.IsNullOrWhiteSpace(ComboBox1.Text) Then
            MessageBox.Show("Selecione uma categoria antes de continuar.", "Categoria obrigatória",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' 2️⃣ Extrai prefixos selecionados no ComboBox
        Dim partes = ComboBox1.Text.Split(";"c)
        Dim prefixosCategoria As New List(Of String)

        For Each parte In partes
            Dim p = parte.Trim()
            If p.Contains("-") Then
                prefixosCategoria.Add(p.Split("-"c)(0).Trim())
            End If
        Next

        If prefixosCategoria.Count = 0 Then Return

        Try
            ' 3️⃣ Documento ativo
            Dim doc As Document = _invApp.ActiveDocument
            If doc Is Nothing OrElse doc.DocumentType <> DocumentTypeEnum.kDrawingDocumentObject Then
                MessageBox.Show("Abra um documento de desenho.", "Erro")
                Return
            End If

            Dim pastaDocumento As String = IO.Path.GetDirectoryName(doc.FullFileName)
            retornoFile = IO.Path.Combine(pastaDocumento, "PrefixosPorFolha.txt")

            ' 4️⃣ Executa a regra iLogic
            Dim iLogicAddIn = _invApp.ApplicationAddIns.ItemById("{3BDD8D79-2179-4B11-8A5A-257B1C0263AC}")
            If Not iLogicAddIn.Activated Then iLogicAddIn.Activate()
            Dim iLogicAuto = iLogicAddIn.Automation

            Dim codigoIlogic As String = LerRegraIncorporada("ExtrairPrefixos")
            codigoIlogic = codigoIlogic.Replace("{PASTA_DOCUMENTO}", pastaDocumento)

            tempRule = IO.Path.Combine(IO.Path.GetTempPath(), "ExtrairPrefixosTemp.ilogic")
            IO.File.WriteAllText(tempRule, codigoIlogic, New System.Text.UTF8Encoding(False))

            Dim metodo = iLogicAuto.GetType().GetMethod(
            "RunExternalRule",
            New Type() {GetType(Document), GetType(String)}
        )
            metodo.Invoke(iLogicAuto, New Object() {doc, tempRule})

            ' 5️⃣ Lê o TXT
            Dim folhaPrefixos As New Dictionary(Of String, List(Of String))

            For Each linha In IO.File.ReadAllLines(retornoFile)
                Dim p = linha.Split("|"c)
                If p.Length = 2 Then
                    folhaPrefixos(p(0).Trim()) =
                    p(1).Split(","c).
                        Select(Function(x) x.Trim()).
                        Where(Function(x) x <> "").
                        ToList()
                End If
            Next

            ' 6️⃣ Marca DataGridView
            Dim selecionadas As Integer = 0

            For Each row As DataGridViewRow In DataGridView1.Rows
                Dim nomeFolha As String = row.Cells("txtNome").Value.ToString()

                If folhaPrefixos.ContainsKey(nomeFolha) Then
                    Dim prefixosInternos = folhaPrefixos(nomeFolha)

                    If prefixosInternos.Any(Function(p) prefixosCategoria.Contains(p)) Then
                        row.Cells("chkSelecionar").Value = True
                        selecionadas += 1
                    End If
                End If
            Next

            MessageBox.Show(
            $"{selecionadas} folhas marcadas por prefixo interno.",
            "Seleção concluída",
            MessageBoxButtons.OK,
            MessageBoxIcon.Information
        )

        Catch ex As Exception
            MessageBox.Show("Erro ao selecionar folhas por prefixo interno: " & ex.Message,
                        "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error)

        Finally
            ' 7️⃣ Limpeza garantida
            Try
                If IO.File.Exists(tempRule) Then IO.File.Delete(tempRule)
                If IO.File.Exists(retornoFile) Then IO.File.Delete(retornoFile)
            Catch
                ' evita erro se o arquivo estiver em uso
            End Try
        End Try
    End Sub

    Private Sub btnVerPrefixosFolhas_Click(sender As Object, e As EventArgs) _
        Handles btnVerPrefixosFolhas.Click

        Dim retornoFile As String = ""
        Dim tempFilePath As String = ""

        Try
            ' 1️⃣ Documento ativo
            Dim doc As Document = _invApp.ActiveDocument
            If doc Is Nothing OrElse doc.DocumentType <> DocumentTypeEnum.kDrawingDocumentObject Then
                MessageBox.Show("Abra um documento de desenho.", "Erro",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            ' Pasta do documento
            Dim pastaDocumento As String = IO.Path.GetDirectoryName(doc.FullFileName)
            retornoFile = IO.Path.Combine(pastaDocumento, "PrefixosPorFolha.txt")

            ' 2️⃣ Ativa iLogic
            Dim iLogicAddIn As ApplicationAddIn =
                _invApp.ApplicationAddIns.ItemById("{3BDD8D79-2179-4B11-8A5A-257B1C0263AC}")

            If iLogicAddIn Is Nothing Then
                MessageBox.Show("Add-In iLogic não encontrado.", "Erro")
                Return
            End If

            If Not iLogicAddIn.Activated Then iLogicAddIn.Activate()
            Dim iLogicAuto As Object = iLogicAddIn.Automation

            If iLogicAuto Is Nothing Then
                MessageBox.Show("Falha ao acessar a automação do iLogic.", "Erro")
                Return
            End If

            ' 3️⃣ Regra iLogic temporária
            Dim codigoIlogic As String = LerRegraIncorporada("ExtrairPrefixos")
            If String.IsNullOrWhiteSpace(codigoIlogic) Then
                MessageBox.Show("Regra iLogic 'ExtrairPrefixos' não encontrada.", "Erro")
                Return
            End If

            codigoIlogic = codigoIlogic.Replace("{PASTA_DOCUMENTO}", pastaDocumento)

            tempFilePath = IO.Path.Combine(IO.Path.GetTempPath(), "ExtrairPrefixosTemp.ilogic")
            IO.File.WriteAllText(tempFilePath, codigoIlogic, New System.Text.UTF8Encoding(False))

            ' 4️⃣ Executa regra
            Dim metodo As Reflection.MethodInfo =
                iLogicAuto.GetType().GetMethod(
                    "RunExternalRule",
                    New Type() {GetType(Document), GetType(String)}
                )

            metodo.Invoke(iLogicAuto, New Object() {doc, tempFilePath})

            ' 5️⃣ Lê TXT
            If Not IO.File.Exists(retornoFile) Then
                MessageBox.Show("Arquivo de prefixos não encontrado.", "Erro")
                Return
            End If

            Dim folhaPrefixos As New Dictionary(Of String, List(Of String))

            For Each linha As String In IO.File.ReadAllLines(retornoFile)
                Dim partes() As String = linha.Split("|"c)
                If partes.Length = 2 Then
                    folhaPrefixos(partes(0).Trim()) =
                        partes(1).Split(","c).
                            Select(Function(x) x.Trim()).
                            Where(Function(x) x <> "").
                            ToList()
                End If
            Next

            ' 6️⃣ Exibe TreeView
            ShowTreeViewForm(folhaPrefixos)

        Catch ex As Exception
            MessageBox.Show("Erro ao obter prefixos via iLogic: " & ex.Message,
                            "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error)

        Finally
            ' 7️⃣ Limpeza garantida
            Try
                If IO.File.Exists(tempFilePath) Then IO.File.Delete(tempFilePath)
                If IO.File.Exists(retornoFile) Then IO.File.Delete(retornoFile)
            Catch
                ' Ignora erro se o arquivo estiver em uso
            End Try
        End Try
    End Sub

    Private Sub ShowTreeViewForm(folhaPrefixos As Dictionary(Of String, List(Of String)))
        Dim form As New Form With {
        .Text = "Prefixos por Folha",
        .Width = 600,
        .Height = 800
    }

        Dim tree As New TreeView With {.Dock = DockStyle.Fill}

        For Each kvp In folhaPrefixos
            Dim folhaNode As New TreeNode(kvp.Key)
            For Each pre In kvp.Value.OrderBy(Function(x) x)
                folhaNode.Nodes.Add(pre)
            Next
            tree.Nodes.Add(folhaNode)
        Next

        ' 🔽 Abre todos os nós
        tree.ExpandAll()

        form.Controls.Add(tree)
        form.ShowDialog()
    End Sub


    Private Function LerRegraIncorporada(parteDoNome As String) As String
        Dim assembly As Reflection.Assembly = Reflection.Assembly.GetExecutingAssembly()
        Dim recursos() As String = assembly.GetManifestResourceNames()
        Dim nomeCompleto As String = recursos.FirstOrDefault(Function(r) r.IndexOf(parteDoNome, StringComparison.OrdinalIgnoreCase) >= 0)
        If String.IsNullOrEmpty(nomeCompleto) Then Return Nothing

        Using stream As IO.Stream = assembly.GetManifestResourceStream(nomeCompleto)
            If stream Is Nothing Then Return Nothing
            Using reader As New IO.StreamReader(stream)
                Return reader.ReadToEnd()
            End Using
        End Using
    End Function



    Private Sub btnSelecionarFrameGenerator_Click(sender As Object, e As EventArgs) Handles btnSelecionarFrameGenerator.Click
        Try
            If DataGridView1.Rows.Count = 0 Then
                MessageBox.Show("Nenhuma folha foi carregada na lista.", "Aviso",
                            MessageBoxButtons.OK, MessageBoxIcon.Information)
                Exit Sub
            End If

            Dim selecionadas As Integer = 0

            ' Percorre todas as linhas do DataGridView
            For Each row As DataGridViewRow In DataGridView1.Rows
                ' Ignora linhas novas ou vazias
                If row.IsNewRow OrElse row.Tag Is Nothing Then Continue For

                Dim sheet As Sheet = TryCast(row.Tag, Sheet)
                If sheet Is Nothing Then Continue For

                Dim marcarLinha As Boolean = False

                ' Percorre todas as views da folha
                For Each drawingView As DrawingView In sheet.DrawingViews
                    Dim desc = drawingView.ReferencedDocumentDescriptor
                    If desc Is Nothing Then Continue For

                    Dim oModel As Document = desc.ReferencedDocument
                    If oModel Is Nothing Then Continue For

                    ' Apenas peças (Parts)
                    If oModel.DocumentType <> DocumentTypeEnum.kPartDocumentObject Then Continue For

                    ' === Verifica se é Frame Generator ===
                    Try
                        If oModel.DocumentInterests.HasInterest("{AC211AE0-A7A5-4589-916D-81C529DA6D17}") Then
                            marcarLinha = True
                            Exit For
                        End If
                    Catch
                        ' Se o documento não suportar DocumentInterests
                        Continue For
                    End Try
                Next

                ' Marca o checkbox se for uma folha com peça do Frame Generator
                If marcarLinha Then
                    If DataGridView1.Columns.Contains("chkSelecionar") Then
                        row.Cells("chkSelecionar").Value = True
                        selecionadas += 1
                    End If
                End If
            Next

            ' Exibe resultado
            MessageBox.Show($"{selecionadas} folha(s) foram selecionadas contendo peças geradas pelo Frame Generator.",
                        "Seleção Concluída", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MessageBox.Show("Erro ao selecionar folhas: " & ex.Message,
                        "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    '==========================================
    ' Evento para ajustar altura de múltiplas linhas
    ' ==========================================
    Private Sub DataGridView1_RowHeightChanged(sender As Object, e As DataGridViewRowEventArgs) Handles DataGridView1.RowHeightChanged
        Dim selecionadas = DataGridView1.SelectedRows
        If selecionadas.Count > 1 Then
            Dim altura = e.Row.Height
            For Each row As DataGridViewRow In selecionadas
                If row.Index <> e.Row.Index Then
                    row.Height = altura
                End If
            Next
        End If
    End Sub
    Private Sub btnSelecionarSheetMetalDobras_Click(sender As Object, e As EventArgs) Handles btnSelecionarSheetMetalDobras.Click
        Try
            If DataGridView1.Rows.Count = 0 Then
                MessageBox.Show("Nenhuma folha foi carregada na lista.", "Aviso",
                            MessageBoxButtons.OK, MessageBoxIcon.Information)
                Exit Sub
            End If

            Dim selecionadas As Integer = 0

            ' Percorre todas as linhas do DataGridView
            For Each row As DataGridViewRow In DataGridView1.Rows
                ' Ignora linhas novas ou vazias
                If row.IsNewRow OrElse row.Tag Is Nothing Then Continue For

                Dim sheet As Sheet = TryCast(row.Tag, Sheet)
                If sheet Is Nothing Then Continue For

                Dim marcarLinha As Boolean = False

                ' Percorre todas as views da folha
                For Each drawingView As DrawingView In sheet.DrawingViews
                    Dim desc = drawingView.ReferencedDocumentDescriptor
                    If desc Is Nothing Then Continue For

                    Dim oModel As Document = desc.ReferencedDocument
                    If oModel Is Nothing Then Continue For

                    ' Apenas peças (Parts)
                    If oModel.DocumentType <> DocumentTypeEnum.kPartDocumentObject Then Continue For

                    ' === Verifica se é uma peça de Chapa Metálica com dobras ===
                    Try
                        If oModel.DocumentSubType.DocumentSubTypeID = "{9C464203-9BAE-11D3-8BAD-0060B0CE6BB4}" Then
                            Dim sm As SheetMetalComponentDefinition =
                            TryCast(oModel.ComponentDefinition, SheetMetalComponentDefinition)

                            If sm IsNot Nothing AndAlso sm.Bends IsNot Nothing AndAlso sm.Bends.Count > 0 Then
                                marcarLinha = True
                                Exit For
                            End If
                        End If
                    Catch
                        Continue For
                    End Try
                Next

                ' Marca o checkbox se for uma folha com peça dobrada
                If marcarLinha Then
                    If DataGridView1.Columns.Contains("chkSelecionar") Then
                        row.Cells("chkSelecionar").Value = True
                        selecionadas += 1
                    End If
                End If
            Next

            ' Exibe resultado
            MessageBox.Show($"{selecionadas} folha(s) foram selecionadas contendo peças de chapa metálica com dobras.",
                        "Seleção Concluída", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MessageBox.Show("Erro ao selecionar folhas de chapa metálica: " & ex.Message,
                        "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnSelecionarMontagensExplodidas_Click(sender As Object, e As EventArgs) Handles btnSelecionarMontagensExplodidas.Click
        Try
            If DataGridView1.Rows.Count = 0 Then
                MessageBox.Show("Nenhuma folha foi carregada na lista.", "Aviso",
                            MessageBoxButtons.OK, MessageBoxIcon.Information)
                Exit Sub
            End If

            Dim selecionadas As Integer = 0

            ' Percorre todas as linhas do DataGridView
            For Each row As DataGridViewRow In DataGridView1.Rows
                If row.IsNewRow OrElse row.Tag Is Nothing Then Continue For

                Dim sheet As Sheet = TryCast(row.Tag, Sheet)
                If sheet Is Nothing Then Continue For

                Dim marcarLinha As Boolean = False

                ' Percorre todas as vistas da folha
                For Each drawingView As DrawingView In sheet.DrawingViews
                    Dim desc = drawingView.ReferencedDocumentDescriptor
                    If desc Is Nothing Then Continue For

                    Dim oModel As Document = desc.ReferencedDocument
                    If oModel Is Nothing Then Continue For

                    ' Verifica se é montagem (.iam) ou apresentação (.ipn)
                    Select Case oModel.DocumentType
                        Case DocumentTypeEnum.kAssemblyDocumentObject
                            marcarLinha = True
                            Exit For

                        Case DocumentTypeEnum.kPresentationDocumentObject
                            marcarLinha = True
                            Exit For
                    End Select
                Next

                ' Marca o checkbox se a folha contém montagem ou vista explodida
                If marcarLinha Then
                    If DataGridView1.Columns.Contains("chkSelecionar") Then
                        row.Cells("chkSelecionar").Value = True
                        selecionadas += 1
                    End If
                End If
            Next

            ' Garante que a primeira folha esteja sempre ativa
            If DataGridView1.Rows.Count > 0 Then
                Dim primeira As DataGridViewRow = DataGridView1.Rows(0)
                primeira.Cells("chkSelecionar").Value = True
            End If

            ' Exibe resultado
            MessageBox.Show($"{selecionadas} folha(s) foram selecionadas contendo montagens ou vistas explodidas.",
                        "Seleção Concluída", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MessageBox.Show("Erro ao selecionar folhas de montagem/explodidas: " & ex.Message,
                        "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnConfirmar_Click(sender As Object, e As EventArgs) Handles btnConfirmar.Click
        Try
            For Each row As DataGridViewRow In DataGridView1.Rows
                Dim sheet As Sheet = CType(row.Tag, Sheet)
                Dim selecionada As Boolean = CBool(row.Cells("chkSelecionar").Value)
                sheet.ExcludeFromPrinting = Not selecionada
            Next

            ' 🧹 Limpeza silenciosa do TXT, se existir
            Try
                Dim doc As Document = _invApp.ActiveDocument
                If doc IsNot Nothing AndAlso Not String.IsNullOrEmpty(doc.FullFileName) Then
                    Dim pastaDocumento As String = IO.Path.GetDirectoryName(doc.FullFileName)
                    Dim retornoFile As String = IO.Path.Combine(pastaDocumento, "PrefixosPorFolha.txt")

                    If IO.File.Exists(retornoFile) Then
                        IO.File.Delete(retornoFile)
                    End If
                End If
            Catch
                ' silencioso – não interrompe o fluxo
            End Try

            MessageBox.Show("Configuração de impressão atualizada com sucesso!",
                        "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information)

            Me.DialogResult = DialogResult.OK
            Me.Close()

        Catch ex As Exception
            MessageBox.Show("Erro ao atualizar folhas: " & ex.Message, "Erro",
                        MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


    ' ================================================================
    ' === OBTÉM LISTA DE FOLHAS SELECIONADAS =========================
    ' ================================================================
    Public Function ObterFolhasSelecionadas() As List(Of Sheet)
        Dim selecionadas As New List(Of Sheet)
        For Each row As DataGridViewRow In DataGridView1.Rows
            If CBool(row.Cells("chkSelecionar").Value) Then
                selecionadas.Add(CType(row.Tag, Sheet))
            End If
        Next
        Return selecionadas
    End Function

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
End Class


' ================================================================
' === CONVERSOR AxHost (igual ao do iLogic) =======================
' ================================================================
Public Class AxHostConverter
    Inherits System.Windows.Forms.AxHost
    Public Sub New()
        MyBase.New((New Guid).ToString)
    End Sub
    Public Function GetImageFromIPictureDisp(ByVal IPDisp As stdole.IPictureDisp) As Image
        Return MyBase.GetPictureFromIPicture(IPDisp)
    End Function
End Class

