﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmSelecionarFolhas
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblInstrucoes = New System.Windows.Forms.Label()
        Me.btnSelecionarTodas = New System.Windows.Forms.Button()
        Me.btnDesmarcarTodas = New System.Windows.Forms.Button()
        Me.btnSelecionarPorPrefixoInterno = New System.Windows.Forms.Button()
        Me.btnConfirmar = New System.Windows.Forms.Button()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.btnSelecionarFrameGenerator = New System.Windows.Forms.Button()
        Me.btnSelecionarSheetMetalDobras = New System.Windows.Forms.Button()
        Me.btnSelecionarMontagensExplodidas = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnVerPrefixosFolhas = New System.Windows.Forms.Button()
        Me.btnSelecionarPrefixo_Folha = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.chkSelecionar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.txtNome = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.imgMiniatura = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblInstrucoes
        '
        Me.lblInstrucoes.AutoSize = True
        Me.lblInstrucoes.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.lblInstrucoes.Location = New System.Drawing.Point(12, 9)
        Me.lblInstrucoes.Name = "lblInstrucoes"
        Me.lblInstrucoes.Size = New System.Drawing.Size(360, 20)
        Me.lblInstrucoes.TabIndex = 0
        Me.lblInstrucoes.Text = "Marque as folhas que deseja incluir na impressão:"
        '
        'btnSelecionarTodas
        '
        Me.btnSelecionarTodas.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnSelecionarTodas.Font = New System.Drawing.Font("Franklin Gothic Medium", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSelecionarTodas.ForeColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.btnSelecionarTodas.Location = New System.Drawing.Point(0, 6)
        Me.btnSelecionarTodas.Name = "btnSelecionarTodas"
        Me.btnSelecionarTodas.Size = New System.Drawing.Size(380, 40)
        Me.btnSelecionarTodas.TabIndex = 2
        Me.btnSelecionarTodas.Text = "Selecionar Todas"
        Me.btnSelecionarTodas.UseVisualStyleBackColor = False
        '
        'btnDesmarcarTodas
        '
        Me.btnDesmarcarTodas.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnDesmarcarTodas.Font = New System.Drawing.Font("Franklin Gothic Medium", 13.8!, System.Drawing.FontStyle.Bold)
        Me.btnDesmarcarTodas.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnDesmarcarTodas.Location = New System.Drawing.Point(0, 48)
        Me.btnDesmarcarTodas.Name = "btnDesmarcarTodas"
        Me.btnDesmarcarTodas.Size = New System.Drawing.Size(380, 40)
        Me.btnDesmarcarTodas.TabIndex = 3
        Me.btnDesmarcarTodas.Text = "Desmarcar Todas"
        Me.btnDesmarcarTodas.UseVisualStyleBackColor = False
        '
        'btnSelecionarPorPrefixoInterno
        '
        Me.btnSelecionarPorPrefixoInterno.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnSelecionarPorPrefixoInterno.Font = New System.Drawing.Font("Franklin Gothic Medium", 13.8!, System.Drawing.FontStyle.Bold)
        Me.btnSelecionarPorPrefixoInterno.Location = New System.Drawing.Point(772, 6)
        Me.btnSelecionarPorPrefixoInterno.Name = "btnSelecionarPorPrefixoInterno"
        Me.btnSelecionarPorPrefixoInterno.Size = New System.Drawing.Size(380, 40)
        Me.btnSelecionarPorPrefixoInterno.TabIndex = 4
        Me.btnSelecionarPorPrefixoInterno.Text = "Selecionar por Prefixos (interno)"
        Me.btnSelecionarPorPrefixoInterno.UseVisualStyleBackColor = False
        '
        'btnConfirmar
        '
        Me.btnConfirmar.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnConfirmar.Font = New System.Drawing.Font("Franklin Gothic Medium", 13.8!, System.Drawing.FontStyle.Bold)
        Me.btnConfirmar.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnConfirmar.Location = New System.Drawing.Point(1541, 48)
        Me.btnConfirmar.Name = "btnConfirmar"
        Me.btnConfirmar.Size = New System.Drawing.Size(380, 40)
        Me.btnConfirmar.TabIndex = 5
        Me.btnConfirmar.Text = "Confirmar"
        Me.btnConfirmar.UseVisualStyleBackColor = False
        '
        'ImageList1
        '
        Me.ImageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.ImageList1.ImageSize = New System.Drawing.Size(16, 16)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        '
        'ComboBox1
        '
        Me.ComboBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(386, 51)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(587, 33)
        Me.ComboBox1.TabIndex = 8
        '
        'btnSelecionarFrameGenerator
        '
        Me.btnSelecionarFrameGenerator.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnSelecionarFrameGenerator.Font = New System.Drawing.Font("Franklin Gothic Medium", 14.0!, System.Drawing.FontStyle.Bold)
        Me.btnSelecionarFrameGenerator.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSelecionarFrameGenerator.Location = New System.Drawing.Point(1158, 6)
        Me.btnSelecionarFrameGenerator.Name = "btnSelecionarFrameGenerator"
        Me.btnSelecionarFrameGenerator.Size = New System.Drawing.Size(380, 40)
        Me.btnSelecionarFrameGenerator.TabIndex = 9
        Me.btnSelecionarFrameGenerator.Text = "Frame"
        Me.btnSelecionarFrameGenerator.UseVisualStyleBackColor = False
        '
        'btnSelecionarSheetMetalDobras
        '
        Me.btnSelecionarSheetMetalDobras.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnSelecionarSheetMetalDobras.Font = New System.Drawing.Font("Franklin Gothic Medium", 14.0!, System.Drawing.FontStyle.Bold)
        Me.btnSelecionarSheetMetalDobras.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSelecionarSheetMetalDobras.Location = New System.Drawing.Point(1541, 6)
        Me.btnSelecionarSheetMetalDobras.Name = "btnSelecionarSheetMetalDobras"
        Me.btnSelecionarSheetMetalDobras.Size = New System.Drawing.Size(380, 40)
        Me.btnSelecionarSheetMetalDobras.TabIndex = 10
        Me.btnSelecionarSheetMetalDobras.Text = "Dobra"
        Me.btnSelecionarSheetMetalDobras.UseVisualStyleBackColor = False
        '
        'btnSelecionarMontagensExplodidas
        '
        Me.btnSelecionarMontagensExplodidas.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnSelecionarMontagensExplodidas.Font = New System.Drawing.Font("Franklin Gothic Medium", 14.0!, System.Drawing.FontStyle.Bold)
        Me.btnSelecionarMontagensExplodidas.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSelecionarMontagensExplodidas.Location = New System.Drawing.Point(1158, 49)
        Me.btnSelecionarMontagensExplodidas.Name = "btnSelecionarMontagensExplodidas"
        Me.btnSelecionarMontagensExplodidas.Size = New System.Drawing.Size(380, 39)
        Me.btnSelecionarMontagensExplodidas.TabIndex = 11
        Me.btnSelecionarMontagensExplodidas.Text = "Montagem"
        Me.btnSelecionarMontagensExplodidas.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.LightSeaGreen
        Me.Panel1.Controls.Add(Me.btnVerPrefixosFolhas)
        Me.Panel1.Controls.Add(Me.btnSelecionarPrefixo_Folha)
        Me.Panel1.Controls.Add(Me.btnSelecionarTodas)
        Me.Panel1.Controls.Add(Me.btnSelecionarSheetMetalDobras)
        Me.Panel1.Controls.Add(Me.btnSelecionarMontagensExplodidas)
        Me.Panel1.Controls.Add(Me.btnDesmarcarTodas)
        Me.Panel1.Controls.Add(Me.btnSelecionarPorPrefixoInterno)
        Me.Panel1.Controls.Add(Me.btnSelecionarFrameGenerator)
        Me.Panel1.Controls.Add(Me.btnConfirmar)
        Me.Panel1.Controls.Add(Me.ComboBox1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 970)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1924, 91)
        Me.Panel1.TabIndex = 12
        '
        'btnVerPrefixosFolhas
        '
        Me.btnVerPrefixosFolhas.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnVerPrefixosFolhas.Font = New System.Drawing.Font("Franklin Gothic Medium", 14.0!, System.Drawing.FontStyle.Bold)
        Me.btnVerPrefixosFolhas.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnVerPrefixosFolhas.Location = New System.Drawing.Point(979, 48)
        Me.btnVerPrefixosFolhas.Name = "btnVerPrefixosFolhas"
        Me.btnVerPrefixosFolhas.Size = New System.Drawing.Size(173, 40)
        Me.btnVerPrefixosFolhas.TabIndex = 13
        Me.btnVerPrefixosFolhas.Text = "Treeview Prefixos"
        Me.btnVerPrefixosFolhas.UseVisualStyleBackColor = False
        '
        'btnSelecionarPrefixo_Folha
        '
        Me.btnSelecionarPrefixo_Folha.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnSelecionarPrefixo_Folha.Font = New System.Drawing.Font("Franklin Gothic Medium", 13.8!, System.Drawing.FontStyle.Bold)
        Me.btnSelecionarPrefixo_Folha.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnSelecionarPrefixo_Folha.Location = New System.Drawing.Point(386, 6)
        Me.btnSelecionarPrefixo_Folha.Name = "btnSelecionarPrefixo_Folha"
        Me.btnSelecionarPrefixo_Folha.Size = New System.Drawing.Size(380, 40)
        Me.btnSelecionarPrefixo_Folha.TabIndex = 12
        Me.btnSelecionarPrefixo_Folha.Text = "Selecionar por Prefixo Folha"
        Me.btnSelecionarPrefixo_Folha.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnSelecionarPrefixo_Folha.UseVisualStyleBackColor = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.AliceBlue
        Me.Panel2.Controls.Add(Me.DataGridView1)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1924, 970)
        Me.Panel2.TabIndex = 13
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.HighlightText
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.chkSelecionar, Me.txtNome, Me.imgMiniatura})
        Me.DataGridView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridView1.GridColor = System.Drawing.SystemColors.WindowText
        Me.DataGridView1.Location = New System.Drawing.Point(0, 0)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersWidth = 51
        Me.DataGridView1.RowTemplate.Height = 70
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(1924, 970)
        Me.DataGridView1.TabIndex = 8
        '
        'chkSelecionar
        '
        Me.chkSelecionar.FillWeight = 52.94118!
        Me.chkSelecionar.HeaderText = "Selecionar"
        Me.chkSelecionar.MinimumWidth = 30
        Me.chkSelecionar.Name = "chkSelecionar"
        '
        'txtNome
        '
        Me.txtNome.FillWeight = 194.1176!
        Me.txtNome.HeaderText = "Nome da Folha"
        Me.txtNome.MinimumWidth = 300
        Me.txtNome.Name = "txtNome"
        '
        'imgMiniatura
        '
        Me.imgMiniatura.FillWeight = 52.94118!
        Me.imgMiniatura.HeaderText = "Miniatura"
        Me.imgMiniatura.MinimumWidth = 6
        Me.imgMiniatura.Name = "imgMiniatura"
        '
        'FrmSelecionarFolhas
        '
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(1924, 1061)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.lblInstrucoes)
        Me.Name = "FrmSelecionarFolhas"
        Me.Text = "Developed by Kreimeier & Machado – Folhas de Desenho: Seleção para Impressão"
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Windows.Forms.Label
    Friend WithEvents clbSheets As Windows.Forms.CheckedListBox
    Friend WithEvents btnSelectAll As Windows.Forms.Button
    Friend WithEvents btnDeselectAll As Windows.Forms.Button
    Friend WithEvents btnSelectByPrefix As Windows.Forms.Button
    Friend WithEvents btnConfirm As Windows.Forms.Button
    Friend WithEvents FlowLayoutPanel1 As Windows.Forms.FlowLayoutPanel
    Friend WithEvents lblInstrucoes As Windows.Forms.Label
    Friend WithEvents btnSelecionarTodas As Windows.Forms.Button
    Friend WithEvents btnDesmarcarTodas As Windows.Forms.Button
    Friend WithEvents btnSelecionarPorPrefixoInterno As Windows.Forms.Button
    Friend WithEvents btnConfirmar As Windows.Forms.Button
    Friend WithEvents ImageList1 As Windows.Forms.ImageList
    Friend WithEvents ComboBox1 As Windows.Forms.ComboBox
    Friend WithEvents btnSelecionarFrameGenerator As Windows.Forms.Button
    Friend WithEvents btnSelecionarSheetMetalDobras As Windows.Forms.Button
    Friend WithEvents btnSelecionarMontagensExplodidas As Windows.Forms.Button
    Friend WithEvents Panel1 As Windows.Forms.Panel
    Friend WithEvents Panel2 As Windows.Forms.Panel
    Friend WithEvents DataGridView1 As Windows.Forms.DataGridView
    Friend WithEvents chkSelecionar As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents txtNome As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents imgMiniatura As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents btnSelecionarPrefixo_Folha As Windows.Forms.Button
    Friend WithEvents btnVerPrefixosFolhas As Windows.Forms.Button
End Class
