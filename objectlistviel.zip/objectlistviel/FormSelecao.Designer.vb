﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormSelecao
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnSelTodos = New System.Windows.Forms.Button()
        Me.btnDesSelTodos = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.tlvModelos = New BrightIdeasSoftware.TreeListView()
        Me.imgIcons = New System.Windows.Forms.ImageList(Me.components)
        Me.Panel1.SuspendLayout()
        CType(Me.tlvModelos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnSelTodos
        '
        Me.btnSelTodos.Location = New System.Drawing.Point(-1, 17)
        Me.btnSelTodos.Margin = New System.Windows.Forms.Padding(2)
        Me.btnSelTodos.Name = "btnSelTodos"
        Me.btnSelTodos.Size = New System.Drawing.Size(200, 32)
        Me.btnSelTodos.TabIndex = 1
        Me.btnSelTodos.Text = "Selecionar Todos "
        Me.btnSelTodos.UseVisualStyleBackColor = True
        '
        'btnDesSelTodos
        '
        Me.btnDesSelTodos.Location = New System.Drawing.Point(200, 17)
        Me.btnDesSelTodos.Margin = New System.Windows.Forms.Padding(2)
        Me.btnDesSelTodos.Name = "btnDesSelTodos"
        Me.btnDesSelTodos.Size = New System.Drawing.Size(200, 32)
        Me.btnDesSelTodos.TabIndex = 2
        Me.btnDesSelTodos.TabStop = False
        Me.btnDesSelTodos.Text = "Desmarcar Todos"
        Me.btnDesSelTodos.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Panel1.Controls.Add(Me.btnOK)
        Me.Panel1.Controls.Add(Me.btnSelTodos)
        Me.Panel1.Controls.Add(Me.btnDesSelTodos)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 561)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1286, 61)
        Me.Panel1.TabIndex = 4
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(399, 17)
        Me.btnOK.Margin = New System.Windows.Forms.Padding(2)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(200, 32)
        Me.btnOK.TabIndex = 3
        Me.btnOK.TabStop = False
        Me.btnOK.Text = "OK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'tlvModelos
        '
        Me.tlvModelos.CellEditUseWholeCell = False
        Me.tlvModelos.CheckBoxes = True
        Me.tlvModelos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlvModelos.GridLines = True
        Me.tlvModelos.HideSelection = False
        Me.tlvModelos.Location = New System.Drawing.Point(0, 0)
        Me.tlvModelos.Name = "tlvModelos"
        Me.tlvModelos.ShowGroups = False
        Me.tlvModelos.ShowImagesOnSubItems = True
        Me.tlvModelos.Size = New System.Drawing.Size(1286, 561)
        Me.tlvModelos.TabIndex = 5
        Me.tlvModelos.UseCompatibleStateImageBehavior = False
        Me.tlvModelos.View = System.Windows.Forms.View.Details
        Me.tlvModelos.VirtualMode = True
        '
        'imgIcons
        '
        Me.imgIcons.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.imgIcons.ImageSize = New System.Drawing.Size(16, 16)
        Me.imgIcons.TransparentColor = System.Drawing.Color.Transparent
        '
        'FormSelecao
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkBlue
        Me.ClientSize = New System.Drawing.Size(1286, 622)
        Me.Controls.Add(Me.tlvModelos)
        Me.Controls.Add(Me.Panel1)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "FormSelecao"
        Me.Opacity = 0.9R
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Formulário de Seleção - Developed by Kreimeier & Machado"
        Me.Panel1.ResumeLayout(False)
        CType(Me.tlvModelos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnSelTodos As Windows.Forms.Button
    Friend WithEvents btnDesSelTodos As Windows.Forms.Button
    Friend WithEvents Panel1 As Windows.Forms.Panel
    Friend WithEvents btnOK As Windows.Forms.Button
    Friend WithEvents tlvModelos As BrightIdeasSoftware.TreeListView
    Friend WithEvents imgIcons As Windows.Forms.ImageList
End Class
