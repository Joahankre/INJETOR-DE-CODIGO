﻿Public Class ModeloNode
    Public Property Label As String
    Public Property FilePath As String
    Public Property Children As List(Of ModeloNode)

    Public Sub New()
        Children = New List(Of ModeloNode)
    End Sub
End Class

