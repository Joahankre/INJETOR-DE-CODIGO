﻿Imports Inventor
Imports System.Windows.Forms

' Classe para armazenar dados do nó da TreeView
Public Class TreeNodeTag
    Public Property FilePath As String
    Public Property PartNumber As String
    Public Property Label As String
End Class

Public Class EditorController

    Private ReadOnly _app As Inventor.Application

    Public Sub New(app As Inventor.Application)
        _app = app
    End Sub

    ' =========================
    ' EXECUÇÃO PRINCIPAL
    ' =========================
    Public Sub Executar()
        ' Verificar se assembly está aberto
        If _app.ActiveDocumentType <> DocumentTypeEnum.kAssemblyDocumentObject Then
            MessageBox.Show("Abra uma montagem (.iam) antes de rodar esta função.", "Erro")
            Exit Sub
        End If

        Dim asmDoc As AssemblyDocument = _app.ActiveDocument

        ' -------------------------------
        ' 1) ABRE FORMULÁRIO DE SELEÇÃO
        ' -------------------------------
        Dim frmSel As New FormSelecao()
        PreencherTreeViewModelData(frmSel.treeModelos, asmDoc)

        If frmSel.ShowDialog() <> DialogResult.OK Then Exit Sub

        Dim modelosSelecionados As List(Of Document) = ObterDocumentosSelecionados(frmSel.treeModelos.Nodes)

        If modelosSelecionados.Count = 0 Then
            MessageBox.Show("Nenhum modelo selecionado.", "Aviso")
            Exit Sub
        End If
        ' -------------------------------
        ' 3) PROCESSA E SALVA DOCUMENTOS
        ' -------------------------------
        For Each oDoc In modelosSelecionados
            Try
                AplicarPropriedades(oDoc,
                                    dados.DataCriacao,
                                    dados.Titulo,
                                    dados.Autor,
                                    dados.Assunto,
                                    dados.Responsavel,
                                    dados.Empresa,
                                    dados.Projetista,
                                    dados.Engenheiro,
                                    dados.Fornecedor,
                                    dados.WebLink,
                                    dados.Acabamento)

                oDoc.Save()
            Catch ex As Exception
                MessageBox.Show("Erro ao atualizar " & oDoc.DisplayName & vbCrLf & ex.Message)
            End Try
        Next

        MessageBox.Show("Propriedades aplicadas com sucesso!", "Finalizado")
    End Sub

    ' =========================
    ' PREENCHE TREEVIEW COM MODEL DATA BOM
    ' =========================
    Private Sub PreencherTreeViewModelData(treeView As TreeView, asmDoc As AssemblyDocument)
        treeView.Nodes.Clear()

        Dim bom As BOM = asmDoc.ComponentDefinition.BOM
        bom.StructuredViewEnabled = True

        Dim modelDataView As BOMView = Nothing
        For Each view As BOMView In bom.BOMViews
            If view.ViewType = BOMViewTypeEnum.kModelDataBOMViewType Then
                modelDataView = view
                Exit For
            End If
        Next

        If modelDataView Is Nothing Then
            MessageBox.Show("BOM do tipo Model Data não encontrada.", "Erro")
            Exit Sub
        End If

        ' Percorre as linhas do Model Data
        For Each row As BOMRow In modelDataView.BOMRows
            AdicionarModelDataNode(row, treeView.Nodes)
        Next

        treeView.ExpandAll()
    End Sub

    Private Sub AdicionarModelDataNode(row As BOMRow, parent As TreeNodeCollection)
        Try
            If row.ComponentDefinitions Is Nothing OrElse row.ComponentDefinitions.Count = 0 Then
                Return
            End If

            Dim compDef As ComponentDefinition = row.ComponentDefinitions.Item(1)

            ' Ignorar Content Center
            If TypeOf compDef Is PartComponentDefinition Then
                Dim pcd = CType(compDef, PartComponentDefinition)
                If pcd.IsContentMember Then Return
            End If

            ' Obter documento (pode ser Nothing para Phantom)
            Dim doc As Document = compDef.Document
            Dim docPath As String = ""
            Dim partNumber As String = ""
            Dim label As String = ""

            If doc IsNot Nothing Then
                docPath = doc.FullFileName
                Try
                    partNumber = doc.PropertySets.Item("Design Tracking Properties").Item("Part Number").Value
                Catch
                End Try
            End If

            ' Se não houver Part Number, usar nome do documento ou definição
            label = If(Not String.IsNullOrWhiteSpace(partNumber), partNumber, If(doc IsNot Nothing, doc.DisplayName, compDef.Name))
            ' ===== FILTRO PARA IGNORAR ITENS =====

            If partNumber.Equals("Conexão aparafusada", StringComparison.InvariantCultureIgnoreCase) Then
                Return ' ignora este nó
            End If
            ' Ignora qualquer Part Number que contenha "Skeleton"
            If partNumber.IndexOf("Skeleton", StringComparison.InvariantCultureIgnoreCase) >= 0 Then
                Return
            End If


            ' Tag do TreeNode
            Dim tag As New TreeNodeTag With {
                .FilePath = docPath,
                .PartNumber = partNumber,
                .Label = label
            }

            ' Criar nó
            Dim node As New TreeNode(label) With {
                .Tag = tag,
                .Name = label
            }
            parent.Add(node)

            ' Recursivo para filhos
            If row.ChildRows IsNot Nothing Then
                For Each child As BOMRow In row.ChildRows
                    AdicionarModelDataNode(child, node.Nodes)
                Next
            End If

        Catch ex As Exception
            Debug.WriteLine("Erro ao adicionar nó Model Data: " & ex.Message)
        End Try
    End Sub

    ' =========================
    ' OBTER DOCUMENTOS SELECIONADOS
    ' =========================
    Private Function ObterDocumentosSelecionados(nodes As TreeNodeCollection) As List(Of Document)
        Dim lista As New List(Of Document)
        ObterDocsRecursivo(nodes, lista)
        Return lista
    End Function

    Private Sub ObterDocsRecursivo(nodes As TreeNodeCollection, lista As List(Of Document))
        For Each node As TreeNode In nodes
            If node.Checked AndAlso node.Tag IsNot Nothing Then
                Dim tag = CType(node.Tag, TreeNodeTag)
                If Not String.IsNullOrWhiteSpace(tag.FilePath) Then
                    Try
                        Dim doc As Document = _app.Documents.OfType(Of Document)() _
                            .FirstOrDefault(Function(d) d.FullFileName = tag.FilePath)
                        If doc Is Nothing Then
                            doc = _app.Documents.Open(tag.FilePath, False)
                        End If
                        lista.Add(doc)
                    Catch ex As Exception
                        MessageBox.Show("Não foi possível abrir o documento: " & tag.FilePath & vbCrLf & ex.Message)
                    End Try
                End If
            End If
            ObterDocsRecursivo(node.Nodes, lista)
        Next
    End Sub
