﻿Imports Inventor
Imports System.Windows.Forms

Public Class EditorController

    Private ReadOnly _app As Inventor.Application

    Public Sub New(app As Inventor.Application)
        _app = app
    End Sub

    Public Sub Executar()

        If _app.ActiveDocumentType <> DocumentTypeEnum.kAssemblyDocumentObject Then
            MessageBox.Show("Abra uma montagem (.iam) antes de usar esta função.")
            Exit Sub
        End If

        Dim asmDoc As AssemblyDocument = _app.ActiveDocument

        ' Usa a tela personalizada
        Dim frmSel As New FormSelecao()

        ' Habilita a BOM estruturada
        Dim bom = asmDoc.ComponentDefinition.BOM
        bom.StructuredViewEnabled = True

        Dim modelView As BOMView =
            bom.BOMViews.Cast(Of BOMView)().
                First(Function(v) v.ViewType = BOMViewTypeEnum.kModelDataBOMViewType)

        frmSel.MontarArvore(modelView.BOMRows)

        If frmSel.ShowDialog() <> DialogResult.OK Then Exit Sub

        Dim docs = frmSel.RetornarDocumentos(_app)

        If docs.Count = 0 Then
            MessageBox.Show("Nenhum item selecionado.")
            Exit Sub
        End If

        ' Você pode implementar aplicação de propriedades aqui

        MessageBox.Show("Propriedades aplicadas com sucesso!")

    End Sub

End Class
