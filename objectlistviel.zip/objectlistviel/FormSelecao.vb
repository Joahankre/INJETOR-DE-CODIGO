﻿Imports System.Windows.Forms
Imports BrightIdeasSoftware
Imports Inventor

Public Class FormSelecao

    Public Sub New()
        InitializeComponent()
        ConfigurarOLV()
    End Sub

    ' ============================================================
    '  CLASSE INTERNA – REPRESENTAÇÃO DOS ITENS DO BOM
    ' ============================================================
    Public Class BomItem
        Public Property Label As String
        Public Property FilePath As String
        Public Property PartNumber As String
        Public Property Quantity As Integer
        Public Property Material As String

        Public Property Thickness As String
        Public Property Diameter As String
        Public Property Width As String

        Public Property Children As New List(Of BomItem)

        Public Overrides Function ToString() As String
            Return Label
        End Function
    End Class

    ' ============================================================
    '  CONFIGURAÇÃO DO TreeListView
    ' ============================================================
    Private Sub ConfigurarOLV()

        tlvModelos.CanExpandGetter = Function(x As Object)
                                         Return CType(x, BomItem).Children.Count > 0
                                     End Function

        tlvModelos.ChildrenGetter = Function(x As Object)
                                        Return CType(x, BomItem).Children
                                    End Function

        tlvModelos.CheckBoxes = True

        ' ---- ATIVA IMAGENS ----
        tlvModelos.SmallImageList = imgIcons


        ' -------- COLUNA: ITEM --------
        Dim colItem As New OLVColumn("Item", "Label")
        colItem.FillsFreeSpace = True
        colItem.MinimumWidth = 150
        tlvModelos.Columns.Add(colItem)

        ' -------- PART NUMBER --------
        Dim colPN As New OLVColumn("Part Number", "PartNumber")
        colPN.Width = 120
        tlvModelos.Columns.Add(colPN)

        ' -------- QUANTIDADE --------
        Dim colQtd As New OLVColumn("Qtd", "Quantity")
        colQtd.Width = 60
        colQtd.TextAlign = HorizontalAlignment.Center
        tlvModelos.Columns.Add(colQtd)

        ' -------- MATERIAL --------
        Dim colMat As New OLVColumn("Material", "Material")
        colMat.Width = 140
        tlvModelos.Columns.Add(colMat)

        ' -------- THICKNESS --------
        Dim colTh As New OLVColumn("Thickness", "Thickness")
        colTh.Width = 80
        tlvModelos.Columns.Add(colTh)

        ' -------- Ø DIÂMETRO --------
        Dim colDia As New OLVColumn("Ø", "Diameter")
        colDia.Width = 80
        tlvModelos.Columns.Add(colDia)

        ' -------- LARGURA --------
        Dim colWidth As New OLVColumn("Largura", "Width")
        colWidth.Width = 80
        tlvModelos.Columns.Add(colWidth)

        ' -------- CAMINHO --------
        Dim colPath As New OLVColumn("Caminho", "FilePath")
        colPath.Width = 250
        tlvModelos.Columns.Add(colPath)

    End Sub

    ' ============================================================
    '  DEFINIR ÍCONE DO ITEM
    ' ============================================================
    Private Function RetornarIcone(rowObject As Object) As Object

        Dim item As BomItem = CType(rowObject, BomItem)

        ' Ícone de pasta (nó com filhos)
        If item.Children IsNot Nothing AndAlso item.Children.Count > 0 Then
            Return "folder"
        End If

        Dim ext As String = IO.Path.GetExtension(item.FilePath).ToLower()

        Select Case ext
            Case ".ipt"
                Return "ipt"
            Case ".iam"
                Return "iam"
            Case ".idw", ".dwg"
                Return "idw"
            Case Else
                Return "unknown"
        End Select

    End Function

    ' ============================================================
    '  MONTAR A ÁRVORE
    ' ============================================================
    Public Sub MontarArvore(rows As BOMRowsEnumerator)

        Dim lista As New List(Of BomItem)

        For Each row As BOMRow In rows
            lista.Add(CriarBomNode(row))
        Next

        tlvModelos.Roots = lista
        tlvModelos.ExpandAll()

    End Sub

    ' ============================================================
    '  CRIA UM NÓ
    ' ============================================================
    Private Function CriarBomNode(row As BOMRow) As BomItem

        Dim item As New BomItem
        Dim doc As Document = Nothing

        Try
            doc = row.ComponentDefinitions.Item(1).Document

            item.FilePath = doc.FullFileName
            item.PartNumber = GetProperty(doc, "Design Tracking Properties", "Part Number")
            item.Material = GetProperty(doc, "Design Tracking Properties", "Material")

            ' ------------------------------
            ' PROPRIEDADES PERSONALIZADAS (CUSTOM)
            ' ------------------------------
            item.Thickness = GetProperty(doc, "Custom", "Thickness")
            item.Diameter = GetProperty(doc, "Custom", "Ø")
            item.Width = GetProperty(doc, "Custom", "LARGURA")

        Catch
            item.FilePath = ""
            item.PartNumber = ""
            item.Material = ""
            item.Thickness = ""
            item.Diameter = ""
            item.Width = ""
        End Try

        item.Label = If(item.PartNumber = "", row.ItemNumber, item.PartNumber)

        Try
            item.Quantity = row.ItemQuantity
        Catch
            item.Quantity = 1
        End Try

        If row.ChildRows IsNot Nothing Then
            For Each child As BOMRow In row.ChildRows
                item.Children.Add(CriarBomNode(child))
            Next
        End If

        Return item
    End Function

    ' ============================================================
    '  PEGAR PROPRIEDADE DO INVENTOR
    ' ============================================================
    Private Function GetProperty(doc As Document, setName As String, propName As String) As String
        Try
            Return doc.PropertySets(setName)(propName).Value.ToString()
        Catch
            Return ""
        End Try
    End Function

    ' ============================================================
    '  DOCUMENTOS SELECIONADOS
    ' ============================================================
    Public Function RetornarDocumentos(app As Inventor.Application) As List(Of Document)

        Dim lista As New List(Of Document)

        For Each o As Object In tlvModelos.CheckedObjects

            Dim item As BomItem = CType(o, BomItem)

            If IO.File.Exists(item.FilePath) Then
                Try
                    lista.Add(app.Documents.Open(item.FilePath, False))
                Catch
                End Try
            End If

        Next

        Return lista
    End Function

    ' ============================================================
    '  BOTÕES
    ' ============================================================
    Private Sub btnSelTodos_Click(sender As Object, e As EventArgs) Handles btnSelTodos.Click
        tlvModelos.CheckAll()
    End Sub

    Private Sub btnDesSelTodos_Click(sender As Object, e As EventArgs) Handles btnDesSelTodos.Click
        tlvModelos.UncheckAll()
    End Sub

    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click

        If tlvModelos.CheckedObjects.Count = 0 Then
            MessageBox.Show("Selecione ao menos um modelo.", "Aviso")
            Exit Sub
        End If

        Me.DialogResult = DialogResult.OK
        Me.Close()

    End Sub

End Class
