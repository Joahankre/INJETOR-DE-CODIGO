﻿Imports System.Drawing
Imports System.IO
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Windows.Forms
Imports Inventor

<ComVisible(True)>
<Guid("e5ac949a-3b42-4e4e-89e4-39639184e9c2")>
Public Class StandardAddInServerBOMDOMA
    Implements ApplicationAddInServer

    Private _inventorApp As Inventor.Application
    Private _automacaoBOMLISTA As AutomacaoBOMDOMA
    Private botaoEdicaoEmMassa As ButtonDefinition

    ' Propriedade de automação
    Public ReadOnly Property Automation As Object Implements ApplicationAddInServer.Automation
        Get
            Return _automacaoBOMLISTA
        End Get
    End Property

    ' Ativação do Add-In
    Public Sub Activate(ByVal addInSiteObject As ApplicationAddInSite, ByVal firstTime As Boolean) Implements ApplicationAddInServer.Activate
        _inventorApp = addInSiteObject.Application
        _automacaoBOMLISTA = New AutomacaoBOMDOMA(_inventorApp)

        Try
            Dim controlDefs As ControlDefinitions = _inventorApp.CommandManager.ControlDefinitions
            Dim assembly As Assembly = Assembly.GetExecutingAssembly()

            ' === CARREGAR ÍCONES EMBUTIDOS ===
            Dim smallIcon As IPictureDisp = LoadIcon(assembly, "16x16.ico")
            Dim largeIcon As IPictureDisp = LoadIcon(assembly, "32x32.ico")

            AddHandler botaoBOMLISTA.OnExecute, AddressOf BotaoBOMLISTA_OnExecute

            ' === ADICIONA O BOTÃO À ABA TOOLS ===
            Dim ribbonAsm As Ribbon = _inventorApp.UserInterfaceManager.Ribbons("Assembly")
            Dim tabTools As RibbonTab = ribbonAsm.RibbonTabs("id_TabTools")

            Dim painel As RibbonPanel = Nothing
            Try
                painel = tabTools.RibbonPanels.Item("PainelBOMLISTA")
            Catch
                painel = tabTools.RibbonPanels.Add("Edição em Massa", "PainelBOMLISTA", Me.GetType().GUID.ToString("B"))
            End Try

            ' Evita duplicação do botão
            Dim existe As Boolean = painel.CommandControls.OfType(Of CommandControl)().
                Any(Function(c) c.ControlDefinition.InternalName = "BOMLISTA")

            If Not existe Then
                painel.CommandControls.AddButton(BotaoBOMLISTA, True)
            End If

        Catch ex As Exception
            MessageBox.Show("Erro ao ativar Add-In: " & ex.Message)
        End Try
    End Sub

    Private Function BotaoBOMLISTA() As ButtonDefinition
        Throw New NotImplementedException()
    End Function

    ' Evento do botão
    Private Sub BotaoBOMLISTA_OnExecute(ByVal Context As NameValueMap)
        Try
            _automacaoBOMLISTA.Sincronizar()
        Catch ex As Exception
            MessageBox.Show("Erro ao executar edição: " & ex.Message)
        End Try
    End Sub

    ' Desativação do Add-In
    Public Sub Deactivate() Implements ApplicationAddInServer.Deactivate
        _inventorApp = Nothing
        _automacaoBOMLISTA = Nothing
    End Sub

    ' Método legado não utilizado
    Public Sub ExecuteCommand(ByVal commandID As Integer) Implements ApplicationAddInServer.ExecuteCommand
    End Sub

    ' === FUNÇÕES AUXILIARES ===
    Private Function LoadIcon(assembly As Assembly, resourceName As String) As IPictureDisp
        Dim iconDisp As IPictureDisp = Nothing
        Try
            Dim resources = assembly.GetManifestResourceNames()
            Dim resource = resources.FirstOrDefault(Function(r) r.EndsWith(resourceName))
            If resource IsNot Nothing Then
                Using stream As Stream = assembly.GetManifestResourceStream(resource)
                    iconDisp = IconToIPictureDisp(New Icon(stream))
                End Using
            End If
        Catch ex As Exception
            MessageBox.Show("Erro ao carregar ícone: " & ex.Message)
        End Try
        Return iconDisp
    End Function

    Private Function IconToIPictureDisp(icon As Icon) As IPictureDisp
        Return AxHostConverter.ImageToPictureDisp(icon.ToBitmap())
    End Function

    Private Class AxHostConverter
        Inherits AxHost
        Private Sub New()
            MyBase.New(String.Empty)
        End Sub
        Public Shared Function ImageToPictureDisp(image As Drawing.Image) As IPictureDisp
            Return CType(GetIPictureDispFromPicture(image), IPictureDisp)
        End Function
    End Class

End Class
