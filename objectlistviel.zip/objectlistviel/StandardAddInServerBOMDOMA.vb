﻿Imports System.Drawing
Imports System.IO
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Windows.Forms
Imports Inventor

<ComVisible(True)>
<Guid("e5ac949a-3b42-4e4e-89e4-39639184e9c2")>
Public Class StandardAddInServerBOMDOMA
    Implements ApplicationAddInServer

    Private _inventorApp As Inventor.Application
    Private _automacaoBOMLISTA As AutomacaoBOMDOMA
    Private botaoBOMLISTA As ButtonDefinition

    Public ReadOnly Property Automation As Object Implements ApplicationAddInServer.Automation
        Get
            Return _automacaoBOMLISTA
        End Get
    End Property

    ' =====================================================================
    ' ATIVAÇÃO DO ADD-IN
    ' =====================================================================
    Public Sub Activate(ByVal addInSiteObject As ApplicationAddInSite,
                        ByVal firstTime As Boolean) Implements ApplicationAddInServer.Activate

        _inventorApp = addInSiteObject.Application
        _automacaoBOMLISTA = New AutomacaoBOMDOMA(_inventorApp)

        Try
            Dim controlDefs As ControlDefinitions = _inventorApp.CommandManager.ControlDefinitions
            Dim assembly As Assembly = Assembly.GetExecutingAssembly()

            ' === CARREGAR ÍCONES EMBUTIDOS ===
            Dim smallIcon As IPictureDisp = LoadIcon(assembly, "16x16.ico")
            Dim largeIcon As IPictureDisp = LoadIcon(assembly, "32x32.ico")

            ' === CRIAR O BOTÃO ===
            botaoBOMLISTA = controlDefs.AddButtonDefinition(
                DisplayName:="Lista BOM",
                InternalName:="BOMLISTA",
                Classification:=CommandTypesEnum.kShapeEditCmdType,
                ClientId:=Me.GetType().GUID.ToString("B"),
                DescriptionText:="Gerar lista Personalizada para Sistema.",
                ToolTipText:="Ferramenta de edição e criação de lista personalizada.",
                StandardIcon:=smallIcon,
                LargeIcon:=largeIcon
            )

            AddHandler botaoBOMLISTA.OnExecute, AddressOf BotaoBOMLISTA_OnExecute

            ' === ADICIONAR BOTÃO NA RIBBON TOOLS DO ASSEMBLY ===
            Dim ribbonAsm As Ribbon = _inventorApp.UserInterfaceManager.Ribbons("Assembly")
            Dim tabTools As RibbonTab = ribbonAsm.RibbonTabs("id_TabTools")

            Dim painel As RibbonPanel = Nothing
            Try
                painel = tabTools.RibbonPanels.Item("PainelBOMLISTA")
            Catch
                painel = tabTools.RibbonPanels.Add("Gerar lista Personalizada", "PainelBOMLISTA",
                                                   Me.GetType().GUID.ToString("B"))
            End Try

            ' Evita duplicação
            Dim existe As Boolean = painel.CommandControls.
                Cast(Of CommandControl).
                Any(Function(c) c.ControlDefinition.InternalName = "BOMLISTA")

            If Not existe Then
                painel.CommandControls.AddButton(botaoBOMLISTA, True)
            End If

        Catch ex As Exception
            MessageBox.Show("Erro ao ativar Add-In: " & ex.Message)
        End Try

    End Sub

    ' =====================================================================
    ' EVENTO DO BOTÃO
    ' =====================================================================
    Private Sub BotaoBOMLISTA_OnExecute(ByVal Context As NameValueMap)
        Try
            _automacaoBOMLISTA.Sincronizar()
        Catch ex As Exception
            MessageBox.Show("Erro ao executar ferramenta: " & ex.Message)
        End Try
    End Sub

    ' =====================================================================
    ' DESATIVAÇÃO
    ' =====================================================================
    Public Sub Deactivate() Implements ApplicationAddInServer.Deactivate
        _inventorApp = Nothing
        _automacaoBOMLISTA = Nothing
        botaoBOMLISTA = Nothing
    End Sub

    Public Sub ExecuteCommand(ByVal commandID As Integer) Implements ApplicationAddInServer.ExecuteCommand
        ' Não utilizado
    End Sub

    ' =====================================================================
    ' UTILITÁRIOS DE ÍCONES
    ' =====================================================================
    Private Function LoadIcon(assembly As Assembly, resourceName As String) As IPictureDisp
        Try
            Dim resource = assembly.GetManifestResourceNames().
                FirstOrDefault(Function(r) r.EndsWith(resourceName))

            If resource Is Nothing Then Return Nothing

            Using stream As Stream = assembly.GetManifestResourceStream(resource)
                Return IconToIPictureDisp(New Icon(stream))
            End Using

        Catch ex As Exception
            MessageBox.Show("Erro ao carregar ícone: " & ex.Message)
            Return Nothing
        End Try
    End Function

    Private Function IconToIPictureDisp(icon As Icon) As IPictureDisp
        Return AxHostConverter.ImageToPictureDisp(icon.ToBitmap())
    End Function

    Private Class AxHostConverter
        Inherits AxHost
        Private Sub New()
            MyBase.New(String.Empty)
        End Sub

        Public Shared Function ImageToPictureDisp(img As Drawing.Image) As IPictureDisp
            Return CType(GetIPictureDispFromPicture(img), IPictureDisp)
        End Function
    End Class

End Class
